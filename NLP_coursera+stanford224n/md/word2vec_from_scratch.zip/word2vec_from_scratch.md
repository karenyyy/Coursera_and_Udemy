
## Word2Vec Concept

###  It has 2 approaches,the Continuous Bag-of-Words model (CBOW) and the Skip-Gram model 

- __CBOW__ predicts target words (e.g. 'mat') from source context words ('the cat sits on the')
  - CBOW smoothes over a lot of the distributional information (by treating an entire context as one observation)
  - useful for __smaller datasets__
- __Skip-gram__ does the inverse and predicts source context-words from the target words.
  -  skip-gram treats each context-target pair as a new observation
  - useful for __larger datasets__


__Vector space models (VSMs)__ represent (embed) words in a continuous vector space where semantically similar words are mapped to nearby points ('are embedded nearby each other'). 

VSMs have a long, rich history in NLP, but all methods depend in some way or another on the Distributional Hypothesis, which states that words that appear in the same contexts share semantic meaning. 

The different approaches that leverage this principle can be divided into two categories: 

- __count-based methods__ (e.g. Latent Semantic Analysis)
  - compute the statistics of how often some word co-occurs with its neighbor words in a large text corpus
  - then map these count-statistics down to a small, dense vector for each word
- __predictive methods__ (e.g. neural probabilistic language models)
  -  directly try to predict a word from its neighbors in terms of learned small, dense embedding vectors
  -  trained using the __maximum likelihood (ML)__ principle to:
    - maximize the probability of the next word  (for "target") 
    - given the previous words  (for "history") in terms of a __softmax function__


\begin{align}
P(w_t | h) &= \text{softmax} (\text{score} (w_t, h)) \\
           &= \frac{\exp \{ \text{score} (w_t, h) \} }
             {\sum_\text{Word w' in Vocab} \exp \{ \text{score} (w', h) \} }
\end{align}


where $\text{score} (w_t, h)$  computes the compatibility of word  with the context $h$, (a dot product is commonly used), 

this model then can be trained by maximizing its __log-likelihood__ on the training set, i.e. by maximizing

\begin{align}
 J_\text{ML} &= \log P(w_t | h) \\
  &= \text{score} (w_t, h) -
     \log \left( \sum_\text{Word w' in Vocab} \exp \{ \text{score} (w', h) \} \right).
\end{align}






## Negative Sampling


###  For feature learning in word2vec we do not need a full probabilistic model ! The CBOW and skip-gram models are instead trained using a binary classification objective (logistic regression) to discriminate the real target words $w_t$ from $k$  imaginary (noise) words $\hat w$, in the same context.

See illustration below:

![](https://www.tensorflow.org/images/softmax-nplm.png)


![](https://www.tensorflow.org/images/nce-nplm.png)


Now, the transformed __Log-likelihood__ is:

### noise-contrastive estimation (NCE) loss (with tf API: tf.nn.nce_loss())

$$J_\text{NEG} = \log Q_\theta(D=1 |w_t, h) +
  k \mathop{\mathbb{E}}_{\tilde w \sim P_\text{noise}}
     \left[ \log Q_\theta(D = 0 |\tilde w, h) \right]$$
     
     
 $$J_\text{NEG} \text{ is maximized when the model assigns high probabilities to the real words, and low probabilities to noise words}$$
     
where the $Q_\theta(D=1 | w, h)$  is the binary logistic regression probability under the model of seeing the word $w$  in the context $h$  in the dataset $D$ , calculated in terms of the learned embedding vectors .

__In practice we approximate the expectation by drawing $k$ contrastive words from the noise distribution __

Computationally it is especially appealing now because computing the loss function now __scales only with the number of noise words that we select ($k$), and not all words in the vocabulary ($V$)__.




## Skip-Gram 


### Example: ```the quick brown fox jumped over the lazy dog```


- The dataset we have:
```([the, brown], quick), ([quick, fox], brown), ([brown, jumped], fox), ...```
- From skip-gram, the task becomes to predict:
```'the' and 'brown' from 'quick', 'quick' and 'fox' from 'brown', etc```
- Therefore the used dataset becomes:
```(quick, the), (quick, brown), (brown, quick), (brown, fox), ...```
-  Observe the first training case above:
  - select __num_noise__ number of noisy (contrastive) examples by drawing from some noise distribution, typically __the unigram distribution__
    - For simplicity let's say __num_noise=1__ and we select __sheep as a noisy example__
  - next we compute the loss for this pair of observed and noisy examples:
  
  
  $$J^{(t)}_\text{NEG} = \log Q_\theta(D=1 | \text{the, quick}) +
  \log(Q_\theta(D=0 | \text{sheep, quick}))$$


$$\text{ The goal is to make an update to the embedding parameters  to maximize this objective function } by \frac{\partial}{\partial \theta} J_\text{NEG}$$


The learned vectors can be visualized by projecting them down to 2 dimensions using for instance something like the __t-SNE__ dimensionality reduction technique.




```python
import collections
import math
import os
import sys
import argparse
import random
from tempfile import gettempdir
import zipfile

import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf

from tensorflow.contrib.tensorboard.plugins import projector
```


```python
## Step 1: Download the data.

url = 'http://mattmahoney.net/dc/'

def check_download(filename):
  print(gettempdir())
  local_filename = os.path.join(gettempdir(), filename)
  if not os.path.exists(local_filename):
    local_filename, _ = urllib.request.urlretrieve(url + filename,
                                                   local_filename)
  statinfo = os.stat(local_filename)
  print(statinfo.st_size)
  return local_filename

filename = check_download('text8.zip')
filename
```

    /tmp
    31344016





    '/tmp/text8.zip'




```python
def read_data(filename):
  ## extract the first file enclosed in the zip as a list of words(and in the zip there's only one file)
  with zipfile.ZipFile(filename) as f:
    print(f.read(f.namelist()[0]).split()[:10]) ## get rid of b''
    data = tf.compat.as_str(f.read(f.namelist()[0])).split()
  return data
```


```python
vocab = read_data(filename)
print(vocab[:10])
```

    [b'anarchism', b'originated', b'as', b'a', b'term', b'of', b'abuse', b'first', b'used', b'against']
    ['anarchism', 'originated', 'as', 'a', 'term', 'of', 'abuse', 'first', 'used', 'against']



```python
print(len(vocab))
```

    17005207



```python
vocab_size = 50000
```


```python
## Step 2: Build the dictionary and replace rare words with UNK token

def build_dataset(words, n_words):
  count = [['UNK', -1]]
  count.extend(collections.Counter(words).most_common(n_words-1))
  # print(count[:10])
  dictionary = dict()
  
  
  """
  In the dictionary:
    
  first word: 1
  second word: 2
  third wird: 3
  ...
  
  """
  for word, _ in count:
    dictionary[word] = len(dictionary)
  
  data = []
  unk_count=0
  for word in words:
    index = dictionary.get(word, 0)
    if index == 0:
      unk_count += 1
    data.append(index)
  count[0][1] = unk_count
  reverse_dictionary = dict(zip(dictionary.values(), dictionary.keys()))
  return data, count, dictionary, reverse_dictionary

```


```python
data, count, dictionary, reverse_dictionary = build_dataset(vocab, vocab_size)
```


```python
vocab[:10]
```




    ['anarchism',
     'originated',
     'as',
     'a',
     'term',
     'of',
     'abuse',
     'first',
     'used',
     'against']




```python
## here, data is the corresponding label of each word in vocab using 'count' dict, which we 
## label as (1st, 1), (2nd, 2), (3rd, 3), (4th, 4), ......

data[:10]
```




    [5234, 3081, 12, 6, 195, 2, 3134, 46, 59, 156]




```python
count[:10]
```




    [['UNK', 418391],
     ('the', 1061396),
     ('of', 593677),
     ('and', 416629),
     ('one', 411764),
     ('in', 372201),
     ('a', 325873),
     ('to', 316376),
     ('zero', 264975),
     ('nine', 250430)]




```python
[(word,index) for word, index in dictionary.items()][:10]
```




    [('UNK', 0),
     ('the', 1),
     ('of', 2),
     ('and', 3),
     ('one', 4),
     ('in', 5),
     ('a', 6),
     ('to', 7),
     ('zero', 8),
     ('nine', 9)]




```python
[(word,index) for word, index in reverse_dictionary.items()][:10]
```




    [(0, 'UNK'),
     (1, 'the'),
     (2, 'of'),
     (3, 'and'),
     (4, 'one'),
     (5, 'in'),
     (6, 'a'),
     (7, 'to'),
     (8, 'zero'),
     (9, 'nine')]




```python
## Step 3: Function to generate a training batch for the skip-gram model

start_index = 0

def generate_batch(batch_size, num_skips, skip_window):
  global start_index
  assert batch_size % num_skips == 0
  assert num_skips <= 2 * skip_window
  
  batch = np.ndarray(shape= (batch_size), dtype = np.int32)
  labels = np.ndarray(shape = (batch_size, 1), dtype = np.int32)
  span = 2 * skip_window + 1 ## [skip_window target_word skip_window]
  buffer = collections.deque(maxlen = span)
  
  if start_index + span > len(data):
    start_index = 0
    
  buffer.extend(data[start_index:start_index+span])
  # print(buffer)
  
  start_index += span
  
  for i in range(batch_size // num_skips):
    ## the sentence that's being processed each time
    context_words = [w for w in range(span) if w != skip_window] ## the index of context_words
    # print("context_words are: ", context_words)
    words_to_use = random.sample(context_words, num_skips)
    # print("words_to_use are: ", words_to_use)
    for j, context_word in enumerate(words_to_use):
      batch[i*num_skips+j] = buffer[skip_window] ## the target word
      labels[i*num_skips+j, 0] = buffer[context_word]
    if start_index == len(data):
      buffer.extend(data[0:span]) ## start over ?
      start_index = span
    else:
      buffer.append(data[start_index])
      start_index += 1
  # Backtrack a little bit to avoid skipping words in the end of a batch
  start_index = (start_index + len(data) - span) % len(data)
  return batch, labels
```


```python
batch, labels = generate_batch(batch_size=8, num_skips=2, skip_window=1)
for i in range(8):
  print('target word index: ', batch[i], ' target word: ', reverse_dictionary[batch[i]], '\n',
        'context word index: ', labels[i, 0], ' context word: ', reverse_dictionary[labels[i, 0]]+'\n')
```

    deque([855, 3581, 1], maxlen=3)
    context_words are:  [0, 2]
    words_to_use are:  [0, 2]
    context_words are:  [0, 2]
    words_to_use are:  [2, 0]
    context_words are:  [0, 2]
    words_to_use are:  [2, 0]
    context_words are:  [0, 2]
    words_to_use are:  [0, 2]
    target word index:  3581  target word:  whilst 
     context word index:  855  context word:  revolution
    
    target word index:  3581  target word:  whilst 
     context word index:  1  context word:  the
    
    target word index:  1  target word:  the 
     context word index:  195  context word:  term
    
    target word index:  1  target word:  the 
     context word index:  3581  context word:  whilst
    
    target word index:  195  target word:  term 
     context word index:  11  context word:  is
    
    target word index:  195  target word:  term 
     context word index:  1  context word:  the
    
    target word index:  11  target word:  is 
     context word index:  195  context word:  term
    
    target word index:  11  target word:  is 
     context word index:  191  context word:  still
    



```python
## Step 4: Build and train a skip-gram model

batch_size = 128
embedding_size = 128  # Dimension of the embedding vector.
skip_window = 1  # How many words to consider left and right.
num_skips = 2  # How many times to reuse an input to generate a label.
num_sampled = 64  # Number of negative examples to sample.

valid_size = 16  # Random set of words to evaluate similarity on.
valid_window = 100  # Only pick dev samples in the head of the distribution.
valid_examples = np.random.choice(valid_window, valid_size, replace=False) ## choose 16 numbers in [0,100]
valid_examples

graph = tf.Graph()

with graph.as_default():
  with tf.name_scope('inputs'):
    train_inputs = tf.placeholder(dtype=tf.int32, shape=[batch_size])
    train_labels = tf.placeholder(dtype=tf.int32, shape=[batch_size, 1])
    valid_dataset = tf.constant(valid_examples, dtype=tf.int32)
    
  with tf.device('/cpu:0'):
    with tf.name_scope('embeddings'):
      embeddings = tf.Variable(tf.random_uniform([vocab_size, embedding_size], -1.0, 1.0))
      embed = tf.nn.embedding_lookup(embeddings, train_inputs)
      
  with tf.name_scope('weights'):
    nce_weights = tf.Variable(tf.truncated_normal([vocab_size, embedding_size], 
                                                  stddev=1.0/math.sqrt(embedding_size)))
  
  with tf.name_scope('biases'):
    nce_biases = tf.Variable(tf.zeros([vocab_size]))
    
  with tf.name_scope('loss'):
    loss = tf.reduce_mean(tf.nn.nce_loss(weights=nce_weights, 
                                         biases = nce_biases, 
                                         labels = train_labels,
                                         inputs = embed, 
                                         num_sampled=num_sampled, 
                                         num_classes=vocab_size))
  tf.summary.scalar('loss', loss)
    
  with tf.name_scope('optimizer'):
    optimizer = tf.train.GradientDescentOptimizer(learning_rate=1.0).minimize(loss)
  
  norm = tf.sqrt(tf.reduce_sum(tf.square(embeddings), axis=1, keep_dims=True)) ## since each row represents a word to be embedded
  normalized_embeddings = embeddings / norm
  valid_embeddings = tf.nn.embedding_lookup(normalized_embeddings, valid_dataset)
  similarity = tf.matmul(valid_embeddings, normalized_embeddings, transpose_b=True)
  
  
  ## training
  merged = tf.summary.merge_all()
  init = tf.global_variables_initializer()
  saver = tf.train.Saver()
```


```python
num_steps = 100001
```


```python
with tf.Session(graph=graph) as sess:
  writer = tf.summary.FileWriter(gettempdir(), session.graph)
  init.run()
  avg_loss = 0
  for step in range(num_steps):
    batch_inputs, batch_labels = generate_batch(batch_size, num_skips, skip_window)
    feed_dict = {train_inputs: batch_inputs, 
                 train_labels: batch_labels}
    run_metadata = tf.RunMetadata()
    _, summary, loss_each_step = sess.run([optimizer, merged, loss], feed_dict=feed_dict, run_metadata = run_metadata)
    # _, summary, loss_each_step = sess.run([optimizer, merged, loss], feed_dict=feed_dict)
    avg_loss += loss_each_step
      
    writer.add_summary(summary, step)
    if step == (num_steps - 1):
      writer.add_run_metadata(run_metadata, 'step%d' % step)

    
    if step % 2000 == 0:
      avg_loss /= 2000
      print('avg_loss is: ', avg_loss)
      avg_loss = 0
    
    if step % 10000 == 0:
        sim = similarity.eval()
        print(sim)
        for i in range(valid_size):
          valid_word = reverse_dictionary[valid_examples[i]]
          top_k = 8  # number of nearest neighbors
          nearest = (-sim[i, :]).argsort()[1:top_k + 1]
          log_str = 'Nearest to %s:' % valid_word
          for k in xrange(top_k):
            close_word = reverse_dictionary[nearest[k]]
            log_str = '%s %s,' % (log_str, close_word)
          print(log_str)
          
  final_embeddings = normalized_embeddings.eval()
  
  with open(gettempdir() + '/metadata.tsv', 'w') as f:
    for i in range(vocabulary_size):
      f.write(reverse_dictionary[i] + '\n')

  saver.save(sess, os.path.join(gettempdir(), 'model.ckpt'))
  
  config = projector.ProjectorConfig()
  embedding_conf = config.embeddings.add()
  embedding_conf.tensor_name = embeddings.name
  embedding_conf.metadata_path = os.path.join(gettempdir(), 'metadata.csv')
  projector.visualize_embeddings(writer, config)
  
writer.close()
```

    avg_loss is:  0.1344014892578125
    [[-0.09739756  0.09499507 -0.11295593 ... -0.22579807  0.04305227
      -0.13360937]
     [-0.09955855  0.13887191 -0.07673094 ... -0.01848329  0.09779158
      -0.05948121]
     [-0.11996415 -0.07772341 -0.00078899 ... -0.01558785  0.17248434
       0.10090243]
     ...
     [-0.06974778 -0.07666438  0.02207815 ... -0.09314959 -0.00557343
       0.02981828]
     [ 0.01035618  0.01908964  0.13167952 ...  0.11569861 -0.15346478
       0.14958973]
     [-0.02065982 -0.10412478  0.16558333 ...  0.11027107 -0.06690156
       0.0125173 ]]
    Nearest to to: joyful, intelligentsia, pouring, tuba, archdiocese, bebe, slips, pahlavi,
    Nearest to be: legislate, dominant, resettlement, mannerist, drop, terminator, methamphetamine, mutate,
    Nearest to also: visionaries, acceptable, shining, subpixel, loris, northward, industrialised, loco,
    Nearest to had: cellular, infected, surfing, strictest, parametric, tetrameter, iron, absolutist,
    Nearest to after: negev, begin, legalisation, darmstadt, pulls, prehistoric, heflin, wai,
    Nearest to during: methionine, learners, modulus, stockpiles, seleucids, earned, semi, faster,
    Nearest to by: lemmon, voce, goebbels, rosetta, mea, hustler, within, targ,
    Nearest to so: mosquito, airframes, contracted, hoover, materialism, subarctic, far, reoccupied,
    Nearest to however: rehabilitation, paddock, rodeo, goals, pooled, carbon, remain, homage,
    Nearest to all: joyful, nazarbayev, slough, irritated, brussels, transfer, livelihood, banu,
    Nearest to five: vermilion, sixths, dorms, housekeeper, timeframe, agathocles, readily, dedication,
    Nearest to these: iala, principalities, joule, academies, waveforms, redrawing, bayesian, cosmology,
    Nearest to can: occasions, foreword, omim, hmac, uncompressed, securely, favored, clarion,
    Nearest to six: bye, toppling, predecessor, lifeboats, ogre, stronghold, cloister, visicalc,
    Nearest to see: leafy, weblogs, acura, amis, losing, qualitatively, retaliatory, bottomed,
    Nearest to which: striking, legnica, molar, cetacea, industries, mechanistic, swine, tangible,
    avg_loss is:  113.84329450321198
    avg_loss is:  52.56152933168411
    avg_loss is:  33.37034673047066
    avg_loss is:  23.66300851905346
    avg_loss is:  17.732033324718476
    [[ 0.3809063   0.34309238  0.4650458  ... -0.16889793 -0.09003675
      -0.07877453]
     [ 0.31004205  0.21392573  0.1825567  ...  0.03258157  0.02003507
      -0.04929178]
     [ 0.37043393  0.26921678  0.21829432 ... -0.06393977  0.08567064
       0.05965907]
     ...
     [ 0.3968913   0.41638443  0.3847048  ... -0.0158026  -0.03993807
      -0.04847124]
     [ 0.32860366  0.33708325  0.32180342 ...  0.11819948 -0.1695494
       0.10245813]
     [ 0.35602933  0.3612458   0.2775811  ...  0.05852495 -0.08569032
      -0.01597455]]
    Nearest to to: in, and, not, aries, tissue, k, of, nine,
    Nearest to be: dominant, dairy, sphere, winter, as, selden, caria, admiral,
    Nearest to also: shining, acceptable, lnot, studio, pederastic, anywhere, mysore, ribbon,
    Nearest to had: was, infected, is, were, iron, surfing, soon, travel,
    Nearest to after: in, standards, begin, cold, against, nd, euphrates, toward,
    Nearest to during: semi, modulus, faster, monic, denmark, consumer, earned, next,
    Nearest to by: in, as, colonial, bound, markov, and, astatine, helped,
    Nearest to so: far, towns, contracted, mi, materialism, tarleton, bckgr, serial,
    Nearest to however: goals, reformation, wall, and, aberdeen, remain, carbon, rehabilitation,
    Nearest to all: aberdeen, small, vs, murray, selden, bckgr, refrigerator, fao,
    Nearest to five: zero, nine, two, jpg, eight, sagan, one, four,
    Nearest to these: admission, darius, since, incoherent, publications, mya, lnot, combine,
    Nearest to can: occasions, coke, measured, imaging, bckgr, immigrants, hakama, essential,
    Nearest to six: zero, nine, vs, eight, three, jpg, aberdeen, five,
    Nearest to see: hyacinthus, results, losing, altenberg, persepolis, phi, white, twin,
    Nearest to which: striking, fao, that, this, and, industries, tangible, commonwealth,
    avg_loss is:  14.22312612771988
    avg_loss is:  11.646658238768577
    avg_loss is:  9.92675354230404
    avg_loss is:  8.496481293320656
    avg_loss is:  7.98601516187191
    [[ 0.41585872  0.39584953  0.4676919  ... -0.14691976 -0.10961026
      -0.0549709 ]
     [ 0.36150086  0.2533969   0.20338234 ...  0.04872639  0.01344566
      -0.05354342]
     [ 0.40915596  0.33297405  0.21515179 ... -0.05727304  0.08281718
       0.04299689]
     ...
     [ 0.5146098   0.5219151   0.46379927 ... -0.02163399 -0.02454984
      -0.10085835]
     [ 0.36404037  0.40987954  0.36208034 ...  0.12909564 -0.15638326
       0.0900239 ]
     [ 0.42105073  0.4224927   0.27576733 ...  0.04583187 -0.07914077
      -0.04196615]]
    Nearest to to: and, not, in, from, nine, can, with, for,
    Nearest to be: have, is, are, as, dominant, winter, was, by,
    Nearest to also: not, there, shining, it, lnot, and, acceptable, sprint,
    Nearest to had: was, were, has, is, and, have, infected, strictest,
    Nearest to after: in, for, against, begin, euphrates, standards, with, nd,
    Nearest to during: methionine, semi, modulus, and, in, faster, monic, for,
    Nearest to by: was, in, as, is, from, for, and, nunnery,
    Nearest to so: hoover, far, contracted, towns, materialism, fins, vetoed, taught,
    Nearest to however: and, goals, wall, reformation, incompressible, rehabilitation, paddock, continuously,
    Nearest to all: small, occultists, knight, selden, fao, aberdeen, retook, murray,
    Nearest to five: nine, zero, eight, six, two, seven, four, three,
    Nearest to these: the, admission, incoherent, publications, darius, his, some, dasyprocta,
    Nearest to can: to, measured, occasions, is, immigrants, bckgr, s, may,
    Nearest to six: nine, eight, five, zero, seven, three, two, four,
    Nearest to see: apatosaurus, losing, hyacinthus, results, infinitely, altenberg, is, one,
    Nearest to which: that, this, striking, fao, hbox, abelian, and, commonwealth,
    avg_loss is:  6.969623657822609
    avg_loss is:  6.840834784269333
    avg_loss is:  6.7398712270259855
    avg_loss is:  6.345964410424233
    avg_loss is:  5.976072947144508
    [[ 0.3612918   0.30383167  0.39950135 ... -0.14231874 -0.11457933
      -0.0591349 ]
     [ 0.26819816  0.25885856  0.1772406  ...  0.06346229  0.0191258
      -0.05482638]
     [ 0.34220603  0.24857163  0.21095973 ... -0.06381731  0.08621576
       0.02896133]
     ...
     [ 0.60918236  0.49181437  0.47975767 ... -0.00087577 -0.0618437
      -0.10802481]
     [ 0.3547822   0.35774666  0.37769195 ...  0.12193432 -0.14537963
       0.09349081]
     [ 0.43468535  0.44386104  0.27664027 ...  0.04290709 -0.08545615
      -0.02931817]]
    Nearest to to: nine, not, can, for, and, with, six, onyx,
    Nearest to be: have, are, is, by, been, were, was, as,
    Nearest to also: it, waas, there, not, which, shining, aorta, lnot,
    Nearest to had: was, has, were, have, is, agouti, operatorname, infected,
    Nearest to after: in, for, against, with, four, trinomial, begin, five,
    Nearest to during: in, methionine, semi, at, modulus, monic, following, for,
    Nearest to by: was, with, in, from, reuptake, as, aorta, and,
    Nearest to so: hoover, far, materialism, prostate, fins, vetoed, towns, contracted,
    Nearest to however: and, wall, but, incompressible, reformation, goals, rehabilitation, that,
    Nearest to all: retook, knight, small, the, fao, them, joyful, occultists,
    Nearest to five: six, eight, seven, four, zero, nine, three, operatorname,
    Nearest to these: some, zx, asheville, publications, incoherent, the, dasyprocta, aoc,
    Nearest to can: may, to, will, is, neville, measured, immigrants, would,
    Nearest to six: five, eight, nine, four, seven, zero, three, operatorname,
    Nearest to see: otimes, apatosaurus, losing, hyacinthus, infinitely, afrikaans, thinkpad, altenberg,
    Nearest to which: that, this, fao, striking, hbox, and, abelian, it,
    avg_loss is:  5.986471806287765
    avg_loss is:  5.632657569050789
    avg_loss is:  5.780765159845352
    avg_loss is:  5.519656288743019
    avg_loss is:  5.239365287303925
    [[ 0.32389936  0.23536564  0.3975307  ... -0.15126178 -0.12582587
      -0.03959079]
     [ 0.26975393  0.2176586   0.19665936 ...  0.06414814  0.0344454
      -0.0452678 ]
     [ 0.35799986  0.25498173  0.22052096 ... -0.06100184  0.08051711
       0.03901785]
     ...
     [ 0.6152807   0.49307138  0.45839822 ... -0.02240032 -0.05019075
      -0.1266755 ]
     [ 0.37251037  0.35156447  0.39566806 ...  0.12099059 -0.13889922
       0.08125583]
     [ 0.45756122  0.4120092   0.28520823 ...  0.02663217 -0.07199514
      -0.04764729]]
    Nearest to to: nine, not, circ, aries, for, zero, can, from,
    Nearest to be: have, is, are, were, been, was, by, as,
    Nearest to also: which, it, there, not, waas, shining, lnot, aorta,
    Nearest to had: has, was, have, were, is, uneven, operatorname, agouti,
    Nearest to after: in, since, against, negev, four, for, trinomial, was,
    Nearest to during: in, at, following, semi, and, of, methionine, through,
    Nearest to by: was, with, in, aorta, from, as, is, nunnery,
    Nearest to so: hoover, far, materialism, contracted, towns, vetoed, prostate, provided,
    Nearest to however: but, and, that, wall, reformation, incompressible, which, agouti,
    Nearest to all: sapkowski, knight, any, them, retook, fao, cracking, dasyprocta,
    Nearest to five: four, eight, six, three, seven, zero, two, nine,
    Nearest to these: some, zx, asheville, their, the, three, many, publications,
    Nearest to can: may, will, would, could, to, neville, must, should,
    Nearest to six: eight, seven, four, five, three, nine, zero, two,
    Nearest to see: otimes, apatosaurus, losing, leafy, thinkpad, acura, afrikaans, counsel,
    Nearest to which: that, this, fao, it, hbox, also, and, abelian,
    avg_loss is:  5.348875846505165
    avg_loss is:  5.281860952377319
    avg_loss is:  5.20224883556366
    avg_loss is:  5.226416264295578
    avg_loss is:  4.974116813182831
    [[ 0.35133284  0.24496189  0.4364484  ... -0.14685382 -0.12648645
      -0.04229031]
     [ 0.31030485  0.20387653  0.23747562 ...  0.0651804   0.02315327
      -0.03106746]
     [ 0.35467413  0.23802136  0.23653193 ... -0.05301946  0.07526794
       0.02970088]
     ...
     [ 0.6102418   0.51462483  0.47290772 ... -0.03483396 -0.03378253
      -0.09152563]
     [ 0.4162452   0.3523417   0.37375763 ...  0.11916411 -0.1454074
       0.08656519]
     [ 0.46454552  0.39697674  0.28483528 ...  0.00386098 -0.07047287
      -0.04333898]]
    Nearest to to: and, nine, violent, can, aries, circ, for, onyx,
    Nearest to be: have, is, been, are, by, was, were, nine,
    Nearest to also: which, it, not, there, waas, aorta, often, shining,
    Nearest to had: has, was, have, were, is, uneven, gb, agouti,
    Nearest to after: four, in, negev, since, while, against, was, before,
    Nearest to during: in, at, following, through, while, and, by, semi,
    Nearest to by: was, be, with, aorta, reuptake, is, in, from,
    Nearest to so: baptisms, contracted, provided, far, towns, taught, ops, materialism,
    Nearest to however: but, and, that, which, reformation, agouti, incompressible, wall,
    Nearest to all: sapkowski, pairings, two, knight, them, four, hallmark, dasyprocta,
    Nearest to five: four, six, three, eight, seven, one, zero, two,
    Nearest to these: some, many, three, zx, their, asheville, pis, publications,
    Nearest to can: may, will, would, could, must, to, should, saskatoon,
    Nearest to six: eight, four, five, seven, three, nine, one, zero,
    Nearest to see: otimes, losing, apatosaurus, leafy, ecclesiastical, thinkpad, counsel, acura,
    Nearest to which: this, that, fao, it, and, also, one, hbox,
    avg_loss is:  5.046778997063637
    avg_loss is:  5.1797243573665614
    avg_loss is:  5.044216058969497
    avg_loss is:  5.072232007026672
    avg_loss is:  4.940217441082001
    [[ 0.31384102  0.23749398  0.38581556 ... -0.14631622 -0.12564391
      -0.04304551]
     [ 0.21900754  0.22952364  0.1786724  ...  0.06738544  0.0204901
      -0.02121391]
     [ 0.3905392   0.2007543   0.2253739  ... -0.05959947  0.05141124
       0.02977547]
     ...
     [ 0.5691856   0.5160149   0.49606404 ... -0.03080778 -0.03237553
      -0.10673419]
     [ 0.37781724  0.31225497  0.37508926 ...  0.12156257 -0.14844443
       0.07578245]
     [ 0.42224437  0.39764234  0.28056565 ... -0.00791484 -0.08917204
      -0.04698667]]
    Nearest to to: can, circ, not, nine, ursus, for, onyx, in,
    Nearest to be: have, been, was, by, were, are, is, being,
    Nearest to also: which, not, waas, there, it, aorta, often, who,
    Nearest to had: has, have, was, were, michelob, gb, uneven, operatorname,
    Nearest to after: in, before, while, since, five, when, against, four,
    Nearest to during: in, at, following, through, while, by, when, next,
    Nearest to by: was, with, be, as, in, eight, aorta, reuptake,
    Nearest to so: baptisms, contracted, provided, towns, wct, secunda, prostate, ops,
    Nearest to however: but, that, ursus, and, which, when, agouti, dasyprocta,
    Nearest to all: sapkowski, wct, three, pairings, any, knight, pulau, hallmark,
    Nearest to five: six, four, three, eight, seven, nine, zero, operatorname,
    Nearest to these: some, many, three, such, their, are, both, zx,
    Nearest to can: may, will, would, could, must, should, cannot, to,
    Nearest to six: five, eight, four, seven, three, nine, two, zero,
    Nearest to see: losing, apatosaurus, otimes, leafy, counsel, ecclesiastical, thinkpad, afrikaans,
    Nearest to which: this, that, fao, it, also, one, there, and,
    avg_loss is:  5.0147474757432935
    avg_loss is:  4.832520485162735
    avg_loss is:  4.603019926428795
    avg_loss is:  4.973367188930512
    avg_loss is:  4.891113802671432
    [[ 0.33712927  0.24832073  0.38865906 ... -0.13342051 -0.11392051
      -0.05617984]
     [ 0.26326326  0.20623522  0.17365067 ...  0.08861214  0.02783074
      -0.02210218]
     [ 0.39061671  0.20370287  0.19900325 ... -0.06654259  0.0498367
       0.02994496]
     ...
     [ 0.6278841   0.47851434  0.44609472 ... -0.00985322 -0.00838615
      -0.13427517]
     [ 0.3536382   0.3305546   0.411445   ...  0.1235343  -0.14642748
       0.08706963]
     [ 0.4496679   0.38538042  0.27521756 ... -0.01334025 -0.07163752
      -0.05679194]]
    Nearest to to: can, onyx, would, circ, might, will, not, aries,
    Nearest to be: been, have, are, by, were, was, is, being,
    Nearest to also: which, often, there, it, waas, not, sometimes, runciman,
    Nearest to had: has, have, was, were, cebus, uneven, gb, michelob,
    Nearest to after: before, while, when, in, since, four, until, was,
    Nearest to during: in, at, following, through, while, callithrix, when, by,
    Nearest to by: was, be, with, as, aorta, been, during, microcebus,
    Nearest to so: baptisms, secunda, towns, wct, provided, contracted, prostate, ops,
    Nearest to however: but, that, and, ursus, which, when, agouti, dasyprocta,
    Nearest to all: sapkowski, some, any, many, wct, pairings, knight, them,
    Nearest to five: six, four, three, eight, seven, zero, nine, two,
    Nearest to these: some, many, such, their, are, both, zx, they,
    Nearest to can: may, will, would, could, must, should, might, cannot,
    Nearest to six: eight, four, seven, five, three, nine, two, zero,
    Nearest to see: counsel, thinkpad, leafy, ecclesiastical, apatosaurus, otimes, losing, afrikaans,
    Nearest to which: that, this, fao, it, also, but, however, there,
    avg_loss is:  4.761497199296952
    avg_loss is:  4.792933887958527
    avg_loss is:  4.728397572398186
    avg_loss is:  4.799269749730826
    avg_loss is:  4.801348780035973
    [[ 0.35234687  0.29683146  0.4083579  ... -0.12238403 -0.11189806
      -0.05281717]
     [ 0.31417975  0.21045226  0.19911447 ...  0.09223112  0.03460003
      -0.01594516]
     [ 0.3794102   0.23433115  0.22694638 ... -0.04115934  0.08041661
       0.01124957]
     ...
     [ 0.6708887   0.51444817  0.43985394 ... -0.02547051  0.00723723
      -0.14036964]
     [ 0.3672753   0.26965082  0.377682   ...  0.10604608 -0.14515714
       0.08981378]
     [ 0.43934843  0.37888786  0.27241135 ... -0.01038373 -0.07678325
      -0.06359394]]
    Nearest to to: iit, ursus, circ, onyx, aries, would, nine, can,
    Nearest to be: been, have, were, by, was, are, being, is,
    Nearest to also: which, often, sometimes, waas, it, now, aorta, there,
    Nearest to had: has, have, was, were, uneven, by, cebus, gb,
    Nearest to after: before, when, while, since, during, in, until, against,
    Nearest to during: in, at, through, following, when, while, after, by,
    Nearest to by: was, be, with, iit, were, during, in, from,
    Nearest to so: baptisms, secunda, provided, prostate, contracted, wct, compl, towns,
    Nearest to however: but, that, ursus, and, when, which, dasyprocta, agouti,
    Nearest to all: some, sapkowski, many, any, wct, these, pairings, busan,
    Nearest to five: six, four, seven, eight, three, nine, zero, two,
    Nearest to these: some, many, such, both, are, all, their, zx,
    Nearest to can: may, will, would, could, must, should, cannot, might,
    Nearest to six: seven, four, eight, five, three, nine, two, zero,
    Nearest to see: leafy, apatosaurus, thinkpad, counsel, otimes, holley, ecclesiastical, losing,
    Nearest to which: that, this, it, fao, but, also, one, however,
    avg_loss is:  4.778361383914947
    avg_loss is:  4.76061901819706
    avg_loss is:  4.759132971525192
    avg_loss is:  4.741902925729752
    avg_loss is:  4.739125956892967
    [[ 0.35489845  0.26160967  0.37583053 ... -0.11587016 -0.10685888
      -0.05753754]
     [ 0.32959303  0.2243799   0.177815   ...  0.10199112  0.03635627
      -0.01081397]
     [ 0.40520078  0.21637034  0.1999565  ... -0.03627158  0.06679133
       0.01357054]
     ...
     [ 0.6314683   0.47879004  0.44717544 ... -0.03086141 -0.01040892
      -0.14106554]
     [ 0.3759696   0.32266134  0.38364154 ...  0.09407716 -0.14666714
       0.07938042]
     [ 0.42873797  0.38580218  0.27408874 ... -0.00804083 -0.09521884
      -0.07303049]]
    Nearest to to: iit, can, circ, will, should, ursus, would, nine,
    Nearest to be: been, have, are, were, was, by, being, is,
    Nearest to also: often, which, sometimes, waas, now, not, it, still,
    Nearest to had: has, have, was, were, gb, cebus, uneven, by,
    Nearest to after: before, when, during, while, since, in, until, was,
    Nearest to during: in, at, through, after, following, when, while, until,
    Nearest to by: was, as, with, iit, in, microcebus, be, globemaster,
    Nearest to so: baptisms, secunda, then, prostate, wct, compl, provided, contracted,
    Nearest to however: but, that, and, ursus, which, while, when, dasyprocta,
    Nearest to all: some, any, many, sapkowski, these, wct, pairings, both,
    Nearest to five: four, seven, eight, six, three, nine, zero, two,
    Nearest to these: some, many, such, both, are, all, their, they,
    Nearest to can: may, will, would, could, must, should, cannot, might,
    Nearest to six: seven, eight, four, five, three, nine, zero, operatorname,
    Nearest to see: leafy, apatosaurus, thinkpad, counsel, ecclesiastical, but, holley, odd,
    Nearest to which: that, this, but, it, however, fao, and, also,
    avg_loss is:  4.682008122086525
    avg_loss is:  4.717359818935394
    avg_loss is:  4.684649402141571
    avg_loss is:  4.603071799397468
    avg_loss is:  4.699621981024742
    [[ 0.33950248  0.24045119  0.37423685 ... -0.1694608  -0.10998191
      -0.04058914]
     [ 0.25916213  0.22335735  0.19165607 ...  0.09769448  0.02117926
      -0.0070876 ]
     [ 0.35793492  0.24354176  0.21166955 ... -0.03640821  0.0620381
      -0.01185561]
     ...
     [ 0.5961321   0.5069891   0.4221638  ... -0.05974047 -0.01777408
      -0.13045837]
     [ 0.35561243  0.3353853   0.39382252 ...  0.08828074 -0.14357801
       0.06878465]
     [ 0.36710033  0.4050042   0.28226724 ... -0.0084092  -0.10071741
      -0.06303648]]
    Nearest to to: iit, circ, can, aries, will, ursus, onyx, would,
    Nearest to be: been, have, were, is, was, are, being, by,
    Nearest to also: often, which, sometimes, now, still, waas, not, actually,
    Nearest to had: has, have, was, were, gb, cebus, uneven, michelob,
    Nearest to after: before, when, during, while, until, since, in, without,
    Nearest to during: in, through, at, after, when, following, while, until,
    Nearest to by: was, be, as, with, been, iit, during, microcebus,
    Nearest to so: then, secunda, baptisms, prostate, wct, contracted, provided, hbox,
    Nearest to however: but, that, although, which, ursus, while, when, dasyprocta,
    Nearest to all: some, many, any, these, both, sapkowski, several, three,
    Nearest to five: four, seven, three, eight, six, nine, zero, two,
    Nearest to these: some, many, such, both, all, are, their, they,
    Nearest to can: may, will, would, could, should, must, cannot, might,
    Nearest to six: seven, eight, five, four, nine, three, operatorname, two,
    Nearest to see: leafy, apatosaurus, thinkpad, holley, odd, counsel, ecclesiastical, arin,
    Nearest to which: that, this, but, fao, it, however, also, there,



```python
! tensorboard --logdir=/tmp
```

    [33mW0702 03:03:25.196280 Reloader plugin_event_accumulator.py:286] Found more than one graph event per run, or there was a metagraph containing a graph_def, as well as one or more graph events.  Overwriting the graph with the newest event.
    [0m[33mW0702 03:03:25.223408 Reloader plugin_event_accumulator.py:286] Found more than one graph event per run, or there was a metagraph containing a graph_def, as well as one or more graph events.  Overwriting the graph with the newest event.
    [0m[33mW0702 03:03:25.234986 Reloader plugin_event_accumulator.py:286] Found more than one graph event per run, or there was a metagraph containing a graph_def, as well as one or more graph events.  Overwriting the graph with the newest event.
    [0m[33mW0702 03:03:25.263107 Reloader plugin_event_accumulator.py:286] Found more than one graph event per run, or there was a metagraph containing a graph_def, as well as one or more graph events.  Overwriting the graph with the newest event.
    [0mTensorBoard 1.9.0 at http://0758f3203bb9:6006 (Press CTRL+C to quit)
    [33mW0702 03:03:25.719891 Reloader plugin_event_accumulator.py:286] Found more than one graph event per run, or there was a metagraph containing a graph_def, as well as one or more graph events.  Overwriting the graph with the newest event.
    [0m[33mW0702 03:03:25.720429 Reloader plugin_event_accumulator.py:294] Found more than one metagraph event per run. Overwriting the metagraph with the newest event.
    [0m^C



```python
## Step 6: Visualize the embeddings

def plot_with_labels(low_dim_embs, labels, filename):
  print(low_dim_embs)
  assert low_dim_embs.shape[0] >= len(labels), 'More labels than embeddings'
  
  for i, label in enumerate(labels):
    x, y = low_dim_embs[i, :]
    plt.scatter(x, y)
    plt.annotate(
        label,
        xy=(x, y),
        xytext=(5, 2),
        textcoords='offset points',
        ha='right',
        va='bottom')

  plt.savefig(filename)

plt.figure(figsize=(18, 18))  # in inches

from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

tsne = TSNE(
      perplexity=30, n_components=2, init='pca', n_iter=5000, method='exact')
plot_only = 1000
low_dim_embs = tsne.fit_transform(final_embeddings[:plot_only, :])
labels = [reverse_dictionary[i] for i in range(plot_only)]
plot_with_labels(low_dim_embs, labels, os.path.join(gettempdir(), 'tsne.png'))

```

    [[ 29.116499  -16.258326 ]
     [ -8.552818   36.60486  ]
     [-45.73714    -7.4358435]
     ...
     [ 19.037436    6.817014 ]
     [ 40.346268   48.888542 ]
     [-35.878864   17.833673 ]]



![png](output_22_1.png)

