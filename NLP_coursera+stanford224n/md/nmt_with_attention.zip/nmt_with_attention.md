
This notebook trains a sequence to sequence (seq2seq) model for Spanish to English translation using [tf.keras](https://www.tensorflow.org/programmers_guide/keras) and [eager execution](https://www.tensorflow.org/programmers_guide/eager). 


After training the model in this notebook, you will be able to input a Spanish sentence, such as *"¿todavia estan en casa?"*, and return the English translation: *"are you still at home?"*

The translation quality is reasonable for a toy example, but the generated attention plot is perhaps more interesting. This shows which parts of the input sentence has the model's attention while translating:

<img src="https://tensorflow.org/images/spanish-english.png" alt="spanish-english attention plot">

Note: This example takes approximately 10 mintues to run on a single P100 GPU.


```python
# Import TensorFlow >= 1.9 and enable eager execution
import tensorflow as tf

tf.enable_eager_execution()

import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

import unicodedata
import re
import numpy as np
import os
import time

print(tf.__version__)
```

    1.9.0-rc1



```python
## enable eager execution gives out result instantly instead of constructing a computational graph first then run in a session 
x = [[2.]]
m = tf.matmul(x, x)
print(m)
```

    tf.Tensor([[4.]], shape=(1, 1), dtype=float32)


## Download and prepare the dataset

We'll use a language dataset provided by http://www.manythings.org/anki/. This dataset contains language translation pairs in the format:

```
May I borrow this book?	¿Puedo tomar prestado este libro?
```

Here are the steps we'll take to prepare the data:

1. Add a *start* and *end* token to each sentence.
2. Clean the sentences by removing special characters.
3. Create a word index and reverse word index (dictionaries mapping from word → id and id → word).
4. Pad each sentence to a maximum length.


```python
# Download the file
path_to_zip = tf.keras.utils.get_file(
    'spa-eng.zip', origin='http://download.tensorflow.org/data/spa-eng.zip', 
    extract=True)

path_to_file = os.path.dirname(path_to_zip)+"/spa-eng/spa.txt"
path_to_file
```

    Downloading data from http://download.tensorflow.org/data/spa-eng.zip
    2646016/2638744 [==============================] - 0s 0us/step





    '/content/.keras/datasets/spa-eng/spa.txt'




```python
# Converts the unicode file to ascii
def unicode_to_ascii(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')

# unicode_to_ascii("¿todavia estan en casa?")
  
def preprocess_sentence(w):
    w = unicode_to_ascii(w.lower().strip())
    
    # creating a space between a word and the punctuation following it
    w = re.sub(r"([?.!,¿])", r" \1 ", w) ## \1 => like xargs in linux shells, pass on the previous parameter to the next task
    w = re.sub(r'[" "]+', " ", w) ## squeeze the long whitespace to one whitespace
    
    # replacing everything with space except (a-z, A-Z, ".", "?", "!", ",")
    w = re.sub(r"[^a-zA-Z?.!,¿]+", " ", w)
    
    w = w.rstrip().strip()
    
    # adding a start and an end token to the sentence
    # so that the model know when to start and stop predicting.
    w = '<start> ' + w + ' <end>'
    return w
  
preprocess_sentence("¿todavia estan en casa?")
```




    '<start> ¿ todavia estan en casa ? <end>'




```python
# 1. Remove the accents
# 2. Clean the sentences
# 3. Return word pairs in the format: [ENGLISH, SPANISH]
def create_dataset(path, num_examples):
    lines = open(path, encoding='UTF-8').read().strip().split('\n')
    
    word_pairs = [[preprocess_sentence(w) for w in l.split('\t')]  for l in lines[:num_examples]]
    
    return word_pairs
```


```python
# This class creates a word -> index mapping (e.g,. "dad" -> 5) and vice-versa 
# (e.g., 5 -> "dad") for each language,
class LanguageIndex():
  def __init__(self, lang):
    self.lang = lang
    self.word2idx = {}
    self.idx2word = {}
    self.vocab = set()
    
    self.create_index()
    
  def create_index(self):
    for phrase in self.lang:
      self.vocab.update(phrase.split(' '))
    
    self.vocab = sorted(self.vocab)
    
    self.word2idx['<pad>'] = 0
    for index, word in enumerate(self.vocab):
      self.word2idx[word] = index + 1
    
    for word, index in self.word2idx.items():
      self.idx2word[index] = word
```


```python
def max_length(tensor):
    return max(len(t) for t in tensor)


def load_dataset(path, num_examples):
    # creating cleaned input, output pairs
    pairs = create_dataset(path, num_examples)
    print(pairs[:10])
    
    # index language using the class defined above    
    inp_lang = LanguageIndex(sp for en, sp in pairs)
    targ_lang = LanguageIndex(en for en, sp in pairs)
 
    
    # Vectorize the input and target languages
    
    # Spanish sentences
    input_tensor = [[inp_lang.word2idx[s] for s in sp.split(' ')] for en, sp in pairs]
    print(input_tensor[:10])
    
    # English sentences
    target_tensor = [[targ_lang.word2idx[s] for s in en.split(' ')] for en, sp in pairs]
  
    print(target_tensor[:10])
    
    # Calculate max_length of input and output tensor
    # Here, we'll set those to the longest sentence in the dataset
    max_length_inp, max_length_tar = max_length(input_tensor), max_length(target_tensor)
    
    # Padding the input and output tensor to the maximum length
    input_tensor = tf.keras.preprocessing.sequence.pad_sequences(input_tensor, 
                                                                 maxlen=max_length_inp,
                                                                 padding='post')
    
    target_tensor = tf.keras.preprocessing.sequence.pad_sequences(target_tensor, 
                                                                  maxlen=max_length_tar, 
                                                                  padding='post')
    
    return input_tensor, target_tensor, inp_lang, targ_lang, max_length_inp, max_length_tar
```

### Limit the size of the dataset to experiment faster (optional)

Training on the complete dataset of >100,000 sentences will take a long time. To train faster, we can limit the size of the dataset to 30,000 sentences (of course, translation quality degrades with less data):


```python
# Try experimenting with the size of that dataset
num_examples = 30000
input_tensor, target_tensor, inp_lang, targ_lang, max_length_inp, max_length_targ = load_dataset(path_to_file, num_examples)
```

    [['<start> go . <end>', '<start> ve . <end>'], ['<start> go . <end>', '<start> vete . <end>'], ['<start> go . <end>', '<start> vaya . <end>'], ['<start> go . <end>', '<start> vayase . <end>'], ['<start> hi . <end>', '<start> hola . <end>'], ['<start> run ! <end>', '<start> corre ! <end>'], ['<start> run . <end>', '<start> corred . <end>'], ['<start> who ? <end>', '<start> ¿ quien ? <end>'], ['<start> fire ! <end>', '<start> fuego ! <end>'], ['<start> fire ! <end>', '<start> incendio ! <end>']]
    [[5, 9090, 3, 4], [5, 9204, 3, 4], [5, 9082, 3, 4], [5, 9089, 3, 4], [5, 4702, 3, 4], [5, 2299, 1, 4], [5, 2304, 3, 4], [5, 9413, 7433, 6, 4], [5, 4270, 1, 4], [5, 4881, 1, 4]]
    [[5, 1857, 3, 4], [5, 1857, 3, 4], [5, 1857, 3, 4], [5, 1857, 3, 4], [5, 2058, 3, 4], [5, 3655, 1, 4], [5, 3655, 3, 4], [5, 4815, 6, 4], [5, 1636, 1, 4], [5, 1636, 1, 4]]



```python
# Creating training and validation sets using an 80-20 split
input_tensor_train, input_tensor_val, target_tensor_train, target_tensor_val = train_test_split(input_tensor, target_tensor, test_size=0.2)

# Show length
len(input_tensor_train), len(target_tensor_train), len(input_tensor_val), len(target_tensor_val)
```




    (24000, 24000, 6000, 6000)




```python
max_length_inp, max_length_targ
```




    (16, 11)



### Create a tf.data dataset


```python
# ## tf.data.Dataset
# from tensorflow.data import Dataset
# import itertools

# def gen():
#   for i in itertools.count(1):
#     yield (i, [1] * i)

# ds = Dataset.from_generator(
#     gen, (tf.int64, tf.int64), (tf.TensorShape([]), tf.TensorShape([None])))
# value = ds.make_one_shot_iterator().get_next()

# print(value)

# filenames = ["/var/data/file1.txt", "/var/data/file2.txt", ...]
# dataset = (Dataset.from_tensor_slices(filenames)
#            .interleave(lambda x:
#                TextLineDataset(x).map(parse_fn, num_parallel_calls=1),
#                cycle_length=4, block_length=16))
```


```python
BUFFER_SIZE = len(input_tensor_train)
BATCH_SIZE = 64
embedding_dim = 256
units = 1024
vocab_inp_size = len(inp_lang.word2idx)
vocab_tar_size = len(targ_lang.word2idx)

dataset = tf.data.Dataset.from_tensor_slices((input_tensor_train, target_tensor_train)).shuffle(BUFFER_SIZE)
dataset = dataset.apply(tf.contrib.data.batch_and_drop_remainder(BATCH_SIZE))

i=5
for (batch, (input_, target)) in enumerate(dataset):
  if i>0:
    print(batch)
    print(input_)
    print(target)
  i -= 1
```

    0
    tf.Tensor(
    [[   5 2541 5498 ...    0    0    0]
     [   5 8099 5498 ...    0    0    0]
     [   5 6211 8099 ...    0    0    0]
     ...
     [   5 4661 4326 ...    0    0    0]
     [   5 5752 3895 ...    0    0    0]
     [   5 5196 6955 ...    0    0    0]], shape=(64, 16), dtype=int32)
    tf.Tensor(
    [[   5 2173 4827 1244 2832  410    3    4    0    0    0]
     [   5 2173 2420 4798 2173 4729    3    4    0    0    0]
     [   5 2173  641 4282 4043 1823    3    4    0    0    0]
     [   5 2173 4738 3458    7  492    3    4    0    0    0]
     [   5 4712 1705 2675    3    4    0    0    0    0    0]
     [   5 4031 1705 4374 1111    3    4    0    0    0    0]
     [   5 1244 4924 2751  509    6    4    0    0    0    0]
     [   5 2173  641 4720 2899 1563    3    4    0    0    0]
     [   5 4459  368 2876    3    4    0    0    0    0    0]
     [   5 4459 2575  310    3    4    0    0    0    0    0]
     [   5 2173 1172 4282 3762 2071    3    4    0    0    0]
     [   5 4016 3664 3036    3    4    0    0    0    0    0]
     [   5 2173 3525    3    4    0    0    0    0    0    0]
     [   5 2323 3664    7 4022    3    4    0    0    0    0]
     [   5 4924 3452    7 1624 2501    1    4    0    0    0]
     [   5 2323  964  355 2214    3    4    0    0    0    0]
     [   5 4760  511 2594 4459    3    4    0    0    0    0]
     [   5 2011 3664    7  604 1304    3    4    0    0    0]
     [   5 4760 3705 2323    3    4    0    0    0    0    0]
     [   5 3076 4379 2222 4374  522    3    4    0    0    0]
     [   5 2173 4864   82    3    4    0    0    0    0    0]
     [   5 3235 1260 4282 1023    3    4    0    0    0    0]
     [   5 2323 4876    3    4    0    0    0    0    0    0]
     [   5 2173  132    7 1874  525    3    4    0    0    0]
     [   5 4924 3452    7 1743    3    4    0    0    0    0]
     [   5 2173 1260 4282 4729 2682    3    4    0    0    0]
     [   5 2173 2521 3211    3    4    0    0    0    0    0]
     [   5 4373 2722 2041    3    4    0    0    0    0    0]
     [   5 4760 2555 3762    3    4    0    0    0    0    0]
     [   5 3065 2151  257 2893    3    4    0    0    0    0]
     [   5 3824 3664 4301 4367 2071    3    4    0    0    0]
     [   5 4786  302    2 4459    3    4    0    0    0    0]
     [   5 2137  208 4924 4451    6    4    0    0    0    0]
     [   5 2173 4742 4282 2102    3    4    0    0    0    0]
     [   5 2478 4488    3    4    0    0    0    0    0    0]
     [   5 3824  318 2675    7  624    3    4    0    0    0]
     [   5 4459 2994 4374  621    3    4    0    0    0    0]
     [   5  161 4374 3400    3    4    0    0    0    0    0]
     [   5 4815 3675 2323    6    4    0    0    0    0    0]
     [   5 4459 3310    3    4    0    0    0    0    0    0]
     [   5 2323 4738    7 4411    3    4    0    0    0    0]
     [   5 2323 3664   14 1646 2728    3    4    0    0    0]
     [   5 2173  641 4282 4146 3979    3    4    0    0    0]
     [   5 2137  889 2319 2323    6    4    0    0    0    0]
     [   5 3856 2173  355 2339    6    4    0    0    0    0]
     [   5 4924 3061 2675 2986    3    4    0    0    0    0]
     [   5 4798    7 3645 2637    1    4    0    0    0    0]
     [   5 2173 2616 2920 1573    3    4    0    0    0    0]
     [   5 2173 2006    7 1978    3    4    0    0    0    0]
     [   5 4459 4731 4449 3762 4647    3    4    0    0    0]
     [   5 2011 2319 4670  673    3    4    0    0    0    0]
     [   5 4792 4282 4924  257 2096    6    4    0    0    0]
     [   5 4892 4924 3308 4319    6    4    0    0    0    0]
     [   5 1627 4459    3    4    0    0    0    0    0    0]
     [   5  208 4924 2388    6    4    0    0    0    0    0]
     [   5 4804  208 4374  948    6    4    0    0    0    0]
     [   5 1825 2323  291 1767 2675    3    4    0    0    0]
     [   5 4924 4665 1884  414    3    4    0    0    0    0]
     [   5 4459 2321 4282 2832 4566    3    4    0    0    0]
     [   5    7 1258 2319    7 2636    3    4    0    0    0]
     [   5 2173  132   83 4732    3    4    0    0    0    0]
     [   5 2173 2618  942    3    4    0    0    0    0    0]
     [   5 2173  132 1827 1294    3    4    0    0    0    0]
     [   5 2173 3464 2521 3211    3    4    0    0    0    0]], shape=(64, 11), dtype=int32)
    1
    tf.Tensor(
    [[   5 5752 7354 ...    0    0    0]
     [   5 9413 3206 ...    0    0    0]
     [   5 8781 8099 ...    0    0    0]
     ...
     [   5 5752 8769 ...    0    0    0]
     [   5 5196 4639 ...    0    0    0]
     [   5 4269 4559 ...    0    0    0]], shape=(64, 16), dtype=int32)
    tf.Tensor(
    [[   5 2173 1883 3872    3    4    0    0    0    0    0]
     [   5 4804 2006 4924  376    6    4    0    0    0    0]
     [   5 4459 2575 3838    3    4    0    0    0    0    0]
     [   5 4459 2319    7 1636 1361    3    4    0    0    0]
     [   5 2011 2805 4449 4456    3    4    0    0    0    0]
     [   5 4459 2319    7 3122  751    3    4    0    0    0]
     [   5 4804 4827 4924 1857    6    4    0    0    0    0]
     [   5 4384 3452 4866    3    4    0    0    0    0    0]
     [   5 4760 3452  997    3    4    0    0    0    0    0]
     [   5 2771 3652 4374 4881    3    4    0    0    0    0]
     [   5 2173 2616 4927 1760    3    4    0    0    0    0]
     [   5 4924 3452 3294    3    4    0    0    0    0    0]
     [   5 2319 4459 3464 1985    6    4    0    0    0    0]
     [   5 4459 2548 2077  784    3    4    0    0    0    0]
     [   5 4374  328 3228 1241    3    4    0    0    0    0]
     [   5 1840 4647 4798 4760 4729    3    4    0    0    0]
     [   5 4924 3452 2521 2675    3    4    0    0    0    0]
     [   5 4798 3664 4459 1254    6    4    0    0    0    0]
     [   5 2173 1053 2521 4449 4391 3990    3    4    0    0]
     [   5 4459 1172 4282 1857 4382    3    4    0    0    0]
     [   5 4459 3664  991    3    4    0    0    0    0    0]
     [   5 2319 4400 4927 1252    6    4    0    0    0    0]
     [   5 4760 3705 4459    3    4    0    0    0    0    0]
     [   5 4374  604 1995 2368 2483    3    4    0    0    0]
     [   5 4459 4738 2037 2127    3    4    0    0    0    0]
     [   5 2173 1584 2899 2986    3    4    0    0    0    0]
     [   5 4815 4827 3131    6    4    0    0    0    0    0]
     [   5 3824 2319   14 2832   84    3    4    0    0    0]
     [   5 4798  208 4924 1254    6    4    0    0    0    0]
     [   5 4374  761 2319 1193    3    4    0    0    0    0]
     [   5 4540  149  632 1276    3    4    0    0    0    0]
     [   5 2173 2616 2920 4459 3664 3902    3    4    0    0]
     [   5 2173 2006 2585 2832 2384    3    4    0    0    0]
     [   5 4459 2319 4397    3    4    0    0    0    0    0]
     [   5 2173 2616 2920 1263 4922    3    4    0    0    0]
     [   5 2323 3664 1987 4449 2370    3    4    0    0    0]
     [   5 4374  624 2319 4312    3    4    0    0    0    0]
     [   5 4760 2006 2741    3    4    0    0    0    0    0]
     [   5 2173 2616 1159    3    4    0    0    0    0    0]
     [   5 2173 4391 4924 3452 2614    3    4    0    0    0]
     [   5 2900 3070 4374 2778    3    4    0    0    0    0]
     [   5 2011 3769 2150    3    4    0    0    0    0    0]
     [   5 2173 2616 4650 4449 2323    3    4    0    0    0]
     [   5 4924 3452 3990 2868    3    4    0    0    0    0]
     [   5 2173 2594 4400 2346    3    4    0    0    0    0]
     [   5 1825 1294    3    4    0    0    0    0    0    0]
     [   5 4459 1313    3    4    0    0    0    0    0    0]
     [   5 3706 4924 2594 2675    3    4    0    0    0    0]
     [   5 4924  641 4282 3108 2049    3    4    0    0    0]
     [   5 2323 3664 2899  420 4389    3    4    0    0    0]
     [   5 4390  208 1628    3    4    0    0    0    0    0]
     [   5 4901 2323 4852    7 3142    3    4    0    0    0]
     [   5 2173 1597 2521  148 2186    3    4    0    0    0]
     [   5 2173 2420 4459 1767 4873    3    4    0    0    0]
     [   5 2804 3042    3    4    0    0    0    0    0    0]
     [   5 4798 2849 4090    1    4    0    0    0    0    0]
     [   5 2173  397 2222 1829    3    4    0    0    0    0]
     [   5 4459 4738 1738    3    4    0    0    0    0    0]
     [   5 2173 2006 2149 3096    3    4    0    0    0    0]
     [   5 2173 2616 2920    7 1246    3    4    0    0    0]
     [   5 4815 4731 4449 3762 2675    6    4    0    0    0]
     [   5 2011 4481 2832 1963    3    4    0    0    0    0]
     [   5 4374 4894 2319 2015    3    4    0    0    0    0]
     [   5 4373 4738    7 2775   89    3    4    0    0    0]], shape=(64, 11), dtype=int32)
    2
    tf.Tensor(
    [[   5 9413 8427 ...    0    0    0]
     [   5 4271 2552 ...    0    0    0]
     [   5 3682 4049 ...    0    0    0]
     ...
     [   5 9393 6211 ...    0    0    0]
     [   5 8781 7438 ...    0    0    0]
     [   5 3774 6228 ...    0    0    0]], shape=(64, 16), dtype=int32)
    tf.Tensor(
    [[   5  208 4924    7 3892    6    4    0    0    0    0]
     [   5 3026 2964 2832 4758    1    4    0    0    0    0]
     [   5 2323 3664 4155    3    4    0    0    0    0    0]
     [   5 4760 3452  257 4374  331    3    4    0    0    0]
     [   5 4924 3452 2521 1553    3    4    0    0    0    0]
     [   5 3824 2319 4588    3    4    0    0    0    0    0]
     [   5 4384 3452 2096    3    4    0    0    0    0    0]
     [   5 4818 2319 4400  312    6    4    0    0    0    0]
     [   5 4924  208   49    3    4    0    0    0    0    0]
     [   5 4760 2585    3    4    0    0    0    0    0    0]
     [   5 2173 2006  796 4461    3    4    0    0    0    0]
     [   5  964 2323  355    7 4687    6    4    0    0    0]
     [   5 2173 2616 4541    3    4    0    0    0    0    0]
     [   5  641 4924 4086 2675 2222    6    4    0    0    0]
     [   5 4803 1244 4760 4104    6    4    0    0    0    0]
     [   5 4815 3664 4842    6    4    0    0    0    0    0]
     [   5 4760 2827 1857    3    4    0    0    0    0    0]
     [   5 2173 2616  302 2222  871    3    4    0    0    0]
     [   5 3824 3664  257    7 2692    3    4    0    0    0]
     [   5 2173  127 2006    7 3217    3    4    0    0    0]
     [   5 2323 4742 4282 3219    3    4    0    0    0    0]
     [   5 2173 3562 4924    2 4459    3    4    0    0    0]
     [   5 3824 3503 2071    3    4    0    0    0    0    0]
     [   5 4289 4459 2261    3    4    0    0    0    0    0]
     [   5 2011 3232 4382    3    4    0    0    0    0    0]
     [   5 1777 2675  148 1369    3    4    0    0    0    0]
     [   5 4373 1252 2319 3990 4191    3    4    0    0    0]
     [   5 4760 3452 2222 2899 2158    3    4    0    0    0]
     [   5  392 2521    7 2637    3    4    0    0    0    0]
     [   5 4924  641 4282 3655  291    3    4    0    0    0]
     [   5 2173  242 1705    7 3433    3    4    0    0    0]
     [   5 2478 2208    1    4    0    0    0    0    0    0]
     [   5 2011 1597  257 2096    3    4    0    0    0    0]
     [   5 2173  132 1781    3    4    0    0    0    0    0]
     [   5 4400 2319 2832 1252    3    4    0    0    0    0]
     [   5 2011 4738  536    3    4    0    0    0    0    0]
     [   5 2173 2552 2222 3631    3    4    0    0    0    0]
     [   5  161 2675    3    4    0    0    0    0    0    0]
     [   5 2173 2521  649    3    4    0    0    0    0    0]
     [   5 4384 4729 4449 2041 4647    3    4    0    0    0]
     [   5 4459 2555 4043    3    4    0    0    0    0    0]
     [   5 2173 4827 2628 4924 1985    3    4    0    0    0]
     [   5 2173 2006 4449 1857 4449 3934    3    4    0    0]
     [   5 2173  132 2920  870 4451    3    4    0    0    0]
     [   5 2498 2675 3762    3    4    0    0    0    0    0]
     [   5 2319 4459  420    6    4    0    0    0    0    0]
     [   5 4760 3572 1705    7 4807    3    4    0    0    0]
     [   5 2049 3664 4374  604    3    4    0    0    0    0]
     [   5 2173 1260 4282 2521 2048    3    4    0    0    0]
     [   5 2323 4738 2368    7 2146    3    4    0    0    0]
     [   5 4798 3664 4374 2667    6    4    0    0    0    0]
     [   5 4373 3664 2920 4533    3    4    0    0    0    0]
     [   5 4459 3939 4374 1960    3    4    0    0    0    0]
     [   5 4371 2222   67    3    4    0    0    0    0    0]
     [   5 4924 1172 4282 2041 2675    3    4    0    0    0]
     [   5 2173 2555  355 1866    3    4    0    0    0    0]
     [   5 4924 1952    7 2570 1078    3    4    0    0    0]
     [   5 4732  562 3026 2222    3    4    0    0    0    0]
     [   5 1260 4282  355 2450    3    4    0    0    0    0]
     [   5 4400 2321 4282 4927 1578    3    4    0    0    0]
     [   5 4384 4705    3    4    0    0    0    0    0    0]
     [   5 2173 2007 4282 1263 4373    3    4    0    0    0]
     [   5 4459 4731 2656  302    3    4    0    0    0    0]
     [   5 2323 4827 1244 1990 4449 4647    3    4    0    0]], shape=(64, 11), dtype=int32)
    3
    tf.Tensor(
    [[   5 3615  374 ...    0    0    0]
     [   5 2714 2552 ...    0    0    0]
     [   5 7441 5498 ...    0    0    0]
     ...
     [   5 8437 8498 ...    0    0    0]
     [   5 5752 2516 ...    0    0    0]
     [   5 5196 7100 ...    0    0    0]], shape=(64, 16), dtype=int32)
    tf.Tensor(
    [[   5 2498 3664 1825 2222 4374  662    3    4    0    0]
     [   5 2323 2319 4638 4449 4924    3    4    0    0    0]
     [   5 2173 4729 4374  410    3    4    0    0    0    0]
     [   5 2319 4373  662 4465 3951    6    4    0    0    0]
     [   5 4459 3825 4327    3    4    0    0    0    0    0]
     [   5 4760 2006 4449  355 3125    3    4    0    0    0]
     [   5 2173 4864 4282 4333 4924    3    4    0    0    0]
     [   5 4374 3271 1995 1297 4638    3    4    0    0    0]
     [   5 4383  208 2737    3    4    0    0    0    0    0]
     [   5 1260 4282 1716   14 4647    1    4    0    0    0]
     [   5 4924 4791  511 1318    3    4    0    0    0    0]
     [   5 2173 2594 4400 3176    3    4    0    0    0    0]
     [   5 2173 2752 2323    3    4    0    0    0    0    0]
     [   5  641 2173 1857 1641    6    4    0    0    0    0]
     [   5 3824 2081 4374  323 1987    3    4    0    0    0]
     [   5 2478 2071  123    3    4    0    0    0    0    0]
     [   5 1244 4924 2420 2048    6    4    0    0    0    0]
     [   5 2137 1244 4924 2521 2334    6    4    0    0    0]
     [   5 4459 3063 2656 2771    3    4    0    0    0    0]
     [   5 2173 2865 2687 2041    3    4    0    0    0    0]
     [   5 3824 3664 2993 2735    3    4    0    0    0    0]
     [   5 3824  361 2071 4449 1089    3    4    0    0    0]
     [   5 2173 2616 2920 3177    3    4    0    0    0    0]
     [   5 4760  116 4730 3584    3    4    0    0    0    0]
     [   5  641 2173 2478    7 2712    6    4    0    0    0]
     [   5 4459 4827 3864 4638    3    4    0    0    0    0]
     [   5 2173  641 4282 4096 2071    3    4    0    0    0]
     [   5 2672 4459 2319 4191    3    4    0    0    0    0]
     [   5 4146 4808    3    4    0    0    0    0    0    0]
     [   5 2173  600 2832 1631    3    4    0    0    0    0]
     [   5 1244 4798 4924 4729    3    4    0    0    0    0]
     [   5 4459 2319    7  430    3    4    0    0    0    0]
     [   5 3390 2323 4382    3    4    0    0    0    0    0]
     [   5 4924 3452 2286    3    4    0    0    0    0    0]
     [   5 4459 1995 3848 1954    3    4    0    0    0    0]
     [   5 4804 3664 4927  300    6    4    0    0    0    0]
     [   5 4400  525 2319 2463    3    4    0    0    0    0]
     [   5 1975 2984 4449 2323    3    4    0    0    0    0]
     [   5 4924  741    3    4    0    0    0    0    0    0]
     [   5 2173 4729 4924 4449 3890    3    4    0    0    0]
     [   5 4382 3664    7  492 2049    3    4    0    0    0]
     [   5 2173 2585 2832 4575    3    4    0    0    0    0]
     [   5 4901 2675    3    4    0    0    0    0    0    0]
     [   5 2011 2319 1357 4449 3453    3    4    0    0    0]
     [   5 1260 4282 2453  257 2071    3    4    0    0    0]
     [   5 2173 1053  613 2323    3    4    0    0    0    0]
     [   5 4459 1490    3    4    0    0    0    0    0    0]
     [   5 1244 4924 1299  840    6    4    0    0    0    0]
     [   5 2323 3664    7  889 2322    3    4    0    0    0]
     [   5 4760 4665  376 2574    3    4    0    0    0    0]
     [   5 2011 4876 1987    3    4    0    0    0    0    0]
     [   5 4551 3601 4382    3    4    0    0    0    0    0]
     [   5 4373 3664 4533    2 4465    3    4    0    0    0]
     [   5 2173 4827 2881 4333    1    4    0    0    0    0]
     [   5 4373 2321 4282 3461    3    4    0    0    0    0]
     [   5 4459 2483 2656    3    4    0    0    0    0    0]
     [   5 4373 3664 2920    7 2822    3    4    0    0    0]
     [   5 2011 4827 3501 4400    3    4    0    0    0    0]
     [   5 4924 4864 4282 3501 2323    3    4    0    0    0]
     [   5 4924 3452 4374  410    3    4    0    0    0    0]
     [   5 2173 2498 4459 4831    3    4    0    0    0    0]
     [   5 2173 2616 2979 1427    3    4    0    0    0    0]
     [   5 2173 2722 2920 1244 4373    3    4    0    0    0]
     [   5 3428 2319 4618    3    4    0    0    0    0    0]], shape=(64, 11), dtype=int32)
    4
    tf.Tensor(
    [[   5 6163 3872 ...    0    0    0]
     [   5 8099 1822 ...    0    0    0]
     [   5 9393 6211 ...    0    0    0]
     ...
     [   5 3669 1949 ...    0    0    0]
     [   5 9413 7360 ...    0    0    0]
     [   5 7441 5716 ...    0    0    0]], shape=(64, 16), dtype=int32)
    tf.Tensor(
    [[   5 2173 2865 4449  355  123    3    4    0    0    0]
     [   5  355 2705    3    4    0    0    0    0    0    0]
     [   5 2173 1244 2920 1857 4449 3722    3    4    0    0]
     [   5 4459 1995  148  113    3    4    0    0    0    0]
     [   5 4459 4738    7 1874 1949    3    4    0    0    0]
     [   5 2011 2525 3894    3    4    0    0    0    0    0]
     [   5 2173 4827 2081 4374 3667    3    4    0    0    0]
     [   5 4459 2319 1717    3    4    0    0    0    0    0]
     [   5 2173 2616 2920 1453  643    3    4    0    0    0]
     [   5 4459 2319    7 3089    3    4    0    0    0    0]
     [   5 4924 2572 4446    3    4    0    0    0    0    0]
     [   5 2376 2323 2222 2734    3    4    0    0    0    0]
     [   5 4924 4296 4465 2812    3    4    0    0    0    0]
     [   5 2323 4738    7 4357    3    4    0    0    0    0]
     [   5 2006 4924 1588 4374 1252    6    4    0    0    0]
     [   5 4760 3452  127 2450    3    4    0    0    0    0]
     [   5 4400 3769 4465 1357    3    4    0    0    0    0]
     [   5 2323 2319    7 1874  624    3    4    0    0    0]
     [   5 4384 4665  116 2483    3    4    0    0    0    0]
     [   5 4400  375 2319 4342    3    4    0    0    0    0]
     [   5 3824 3644 2048 1522    3    4    0    0    0    0]
     [   5 3433 4927 1972    3    4    0    0    0    0    0]
     [   5 4459 1311 4449 4873    3    4    0    0    0    0]
     [   5 2323 3664 4032 2964 4155    3    4    0    0    0]
     [   5 4459 2523 2323    3    4    0    0    0    0    0]
     [   5 2173 2551 2222 4400  209    3    4    0    0    0]
     [   5 4113 1684    3    4    0    0    0    0    0    0]
     [   5 3235 1260 4282 1023    3    4    0    0    0    0]
     [   5 4459  127 2422    3    4    0    0    0    0    0]
     [   5 2011 3664 4670 2567    3    4    0    0    0    0]
     [   5 4459 2319    7 1874 1304    3    4    0    0    0]
     [   5 2173 2420 4459 2319 1985    3    4    0    0    0]
     [   5 4924  641 1857 2930    2 3899    3    4    0    0]
     [   5 2011 3664  991   14 4924    3    4    0    0    0]
     [   5 2011 3696 2984 4374  331    3    4    0    0    0]
     [   5 2173  641 4282 4597 2323    3    4    0    0    0]
     [   5  862  302 4461    3    4    0    0    0    0    0]
     [   5 2173  517 4400 1705 4459    3    4    0    0    0]
     [   5 4400 1964 2319 2737    3    4    0    0    0    0]
     [   5 4819 1171 4924 2075 2675    6    4    0    0    0]
     [   5 2011  807 2077 4414    3    4    0    0    0    0]
     [   5 2173 1720 2048 2843    3    4    0    0    0    0]
     [   5 2323 2319    7 1874  638    3    4    0    0    0]
     [   5 2173 4391 4459 2319    7 2501    3    4    0    0]
     [   5 2011 1952    7 2150 2572    3    4    0    0    0]
     [   5 2173 2006 2899 1601    3    4    0    0    0    0]
     [   5 2173 2594 4927 1293    3    4    0    0    0    0]
     [   5 4798 3664 4400   14    6    4    0    0    0    0]
     [   5 4459 1251 4282 2420 2656    3    4    0    0    0]
     [   5 2011 2319    7 4483  941    3    4    0    0    0]
     [   5 3824 2321 4282 4382    3    4    0    0    0    0]
     [   5 4400 1799 2319 3990 1987    3    4    0    0    0]
     [   5 2011 4562 2832  216    3    4    0    0    0    0]
     [   5 1260 4282 1857 4449  509    3    4    0    0    0]
     [   5 4333 4647 4374 4539    3    4    0    0    0    0]
     [   5 4924  641 4282 1857 4382    3    4    0    0    0]
     [   5 2173 2616 4459 3664 4825    3    4    0    0    0]
     [   5 4459 2573 3169    3    4    0    0    0    0    0]
     [   5 2137 2150  208 4924    6    4    0    0    0    0]
     [   5 4786    3    4    0    0    0    0    0    0    0]
     [   5 4459  127 2422    3    4    0    0    0    0    0]
     [   5 4760 4791 2521  567    3    4    0    0    0    0]
     [   5 4798 4738 4373 2903    6    4    0    0    0    0]
     [   5 2173 4729 2783    3    4    0    0    0    0    0]], shape=(64, 11), dtype=int32)


## Write the encoder and decoder model

Here, we'll implement an encoder-decoder model with attention which you can read about in the TensorFlow [Neural Machine Translation (seq2seq) tutorial](https://www.tensorflow.org/tutorials/seq2seq). This example uses a more recent set of APIs. This notebook implements the [attention equations](https://www.tensorflow.org/tutorials/seq2seq#background_on_the_attention_mechanism) from the seq2seq tutorial. The following diagram shows that each input words is assigned a weight by the attention mechanism which is then used by the decoder to predict the next word in the sentence.

<img src="https://www.tensorflow.org/images/seq2seq/attention_mechanism.jpg" width="500" alt="attention mechanism">

The input is put through an encoder model which gives us the encoder output of shape *(batch_size, max_length, hidden_size)* and the encoder hidden state of shape *(batch_size, hidden_size)*. 

Here are the equations that are implemented:

<img src="https://www.tensorflow.org/images/seq2seq/attention_equation_0.jpg" alt="attention equation 0" width="800">
<img src="https://www.tensorflow.org/images/seq2seq/attention_equation_1.jpg" alt="attention equation 1" width="800">

We're using *Bahdanau attention*. Lets decide on notation before writing the simplified form:

* FC = Fully connected (dense) layer
* EO = Encoder output
* H = hidden state
* X = input to the decoder

And the pseudo-code:

* `score = FC(tanh(FC(EO) + FC(H)))`
* `attention weights = softmax(score, axis = 1)`. Softmax by default is applied on the last axis but here we want to apply it on the *1st axis*, since the shape of score is *(batch_size, max_length, hidden_size)*. `Max_length` is the length of our input. Since we are trying to assign a weight to each input, softmax should be applied on that axis.
* `context vector = sum(attention weights * EO, axis = 1)`. Same reason as above for choosing axis as 1.
* `embedding output` = The input to the decoder X is passed through an embedding layer.
* `merged vector = concat(embedding output, context vector)`
* This merged vector is then given to the GRU
  
The shapes of all the vectors at each step have been specified in the comments in the code:


```python
tf.test.is_gpu_available()
```




    True



### Glorot uniform initializer, also called Xavier uniform initializer.

- It draws samples from a uniform distribution within [-limit, limit] where limit is $\sqrt{\frac{6}{fan\_in + fan\_out}}$ 
  - __fan_in__ is the number of input units in the weight tensor 
  - __fan_out__ is the number of output units in the weight tensor.


```python
def gru(units):
  if tf.test.is_gpu_available():
    return tf.keras.layers.CuDNNGRU(units, 
                                    return_sequences=True, 
                                    return_state=True, 
                                    recurrent_initializer='glorot_uniform')
  else:
    return tf.keras.layers.GRU(units, 
                               return_sequences=True, 
                               return_state=True, 
                               recurrent_activation='sigmoid', 
                               recurrent_initializer='glorot_uniform')
```


```python
class Encoder(tf.keras.Model):
    def __init__(self, vocab_size, embedding_dim, enc_units, batch_sz):
        super(Encoder, self).__init__()
        self.batch_sz = batch_sz
        self.enc_units = enc_units
        self.embedding = tf.keras.layers.Embedding(vocab_size, embedding_dim)
        self.gru = gru(self.enc_units)
        
    def call(self, x, hidden):
        x = self.embedding(x)
        output, state = self.gru(x, initial_state = hidden)        
        return output, state
    
    def initialize_hidden_state(self):
        return tf.zeros((self.batch_sz, self.enc_units))
```


```python
class Decoder(tf.keras.Model):
    def __init__(self, vocab_size, embedding_dim, dec_units, batch_sz):
        super(Decoder, self).__init__()
        self.batch_sz = batch_sz
        self.dec_units = dec_units
        self.embedding = tf.keras.layers.Embedding(vocab_size, embedding_dim)
        self.gru = gru(self.dec_units)
        self.fc = tf.keras.layers.Dense(vocab_size)
        
        # used for attention
        self.W1 = tf.keras.layers.Dense(self.dec_units)
        self.W2 = tf.keras.layers.Dense(self.dec_units)
        self.V = tf.keras.layers.Dense(1)
        
    def call(self, x, hidden, enc_output):
        # enc_output shape == (batch_size, max_length, hidden_size)
        
        # hidden shape == (batch_size, hidden size)
        # hidden_with_time_axis shape == (batch_size, 1, hidden size)
        hidden_with_time_axis = tf.expand_dims(hidden, 1)
        
        # score shape == (batch_size, max_length, hidden_size)
        score = tf.nn.tanh(self.W1(enc_output) + self.W2(hidden_with_time_axis))
        
        # attention_weights shape == (batch_size, max_length, 1)
        # we get 1 at the last axis because we are applying score to self.V
        attention_weights = tf.nn.softmax(self.V(score), axis=1)
        
        # context_vector shape after sum == (batch_size, hidden_size)
        context_vector = attention_weights * enc_output
        context_vector = tf.reduce_sum(context_vector, axis=1)
        
        # x shape after passing through embedding == (batch_size, 1, embedding_dim)
        x = self.embedding(x)
        
        # x shape after concatenation == (batch_size, 1, embedding_dim + hidden_size)
        x = tf.concat([tf.expand_dims(context_vector, 1), x], axis=-1)
        
        # passing the concatenated vector to the GRU
        output, state = self.gru(x)
        
        # output shape == (batch_size * max_length, hidden_size)
        output = tf.reshape(output, (-1, output.shape[2]))
        
        # output shape == (batch_size * max_length, vocab)
        x = self.fc(output)
        
        return x, state, attention_weights
        
    def initialize_hidden_state(self):
        return tf.zeros((self.batch_sz, self.dec_units))
```


```python
encoder = Encoder(vocab_inp_size, embedding_dim, units, BATCH_SIZE)
decoder = Decoder(vocab_tar_size, embedding_dim, units, BATCH_SIZE)
```

## Define the optimizer and the loss function


```python
optimizer = tf.train.AdamOptimizer()

def loss_function(real, pred):
  mask = 1 - np.equal(real, 0) ## if real == 0, then 1 - True = 0; otherwise 1- Flase = 1
  loss_ = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=real, logits=pred) * mask ## is real is 0 padded, no loss burdened to save computation
  return tf.reduce_mean(loss_)
```

## Training

1. Pass the *input* through the *encoder* which return *encoder output* and the *encoder hidden state*.
2. The encoder output, encoder hidden state and the decoder input (which is the *start token*) is passed to the decoder.
3. The decoder returns the *predictions* and the *decoder hidden state*.
4. The decoder hidden state is then passed back into the model and the predictions are used to calculate the loss.
5. Use *teacher forcing* to decide the next input to the decoder.
6. *Teacher forcing* is the technique where the *target word* is passed as the *next input* to the decoder.
  - Teacher forcing is a method for quickly and efficiently training recurrent neural network models that use the output from a prior time step as input.
7. The final step is to calculate the gradients and apply it to the optimizer and backpropagate.


```python
EPOCHS = 10

for epoch in range(EPOCHS):
    start = time.time()
    hidden = encoder.initialize_hidden_state()
    total_loss = 0
    for (batch, (inp, targ)) in enumerate(dataset):
        # inp shape : (64 x 16)
        # targ shape : (64 x 11)
        loss = 0       
        with tf.GradientTape() as tape:
            enc_output, enc_hidden = encoder(inp, hidden) ## execute the 'call' function defined in Class Encoder
            dec_hidden = enc_hidden
            # targ_lang = LanguageIndex(en for en, sp in pairs)
            # initialize the dec_input
            dec_input = tf.expand_dims([targ_lang.word2idx['<start>']] * BATCH_SIZE, 1)       
            
            # Teacher forcing - feeding the target as the next input
            # targ.shape[1]: words in a sentence
            for t in range(1, targ.shape[1]):
                # passing enc_output to the decoder
                # no need to acquire the attention weights
                predictions, dec_hidden, _ = decoder(dec_input, dec_hidden, enc_output)
               
                # predictions shape == (batch_size * max_length, vocab)
                #        targ shape == (batch_size *     1     , vocab)      
                loss += loss_function(targ[:, t], predictions)
                
                # using teacher forcing
                # targ shape == (batch_size, 1, vocab)
                dec_input = tf.expand_dims(targ[:, t], 1)
        
        total_loss += (loss / int(targ.shape[1])) # targ.shape[1] = max_length
        
        variables = encoder.variables + decoder.variables
        
        gradients = tape.gradient(loss, variables)
        
      
        optimizer.apply_gradients(zip(gradients, variables), tf.train.get_or_create_global_step())

        if batch % 100 == 0:
            print('Epoch {} Batch {} Loss {:.4f}'.format(epoch + 1,
                                                         batch,
                                                         loss.numpy() / int(targ.shape[1])))
    
    print('Epoch {} Loss {:.4f}'.format(epoch + 1,
                                        total_loss/len(input_tensor)))
    print('Time taken for 1 epoch {} sec\n'.format(time.time() - start))
```

    Epoch 1 Batch 0 Loss 0.0782
    Epoch 1 Batch 100 Loss 0.0607
    Epoch 1 Batch 200 Loss 0.1216
    Epoch 1 Batch 300 Loss 0.1169
    Epoch 1 Loss 0.0012
    Time taken for 1 epoch 107.04331493377686 sec
    
    Epoch 2 Batch 0 Loss 0.0739
    Epoch 2 Batch 100 Loss 0.1151
    Epoch 2 Batch 200 Loss 0.1025
    Epoch 2 Batch 300 Loss 0.1009
    Epoch 2 Loss 0.0011
    Time taken for 1 epoch 106.87625813484192 sec
    
    Epoch 3 Batch 0 Loss 0.0712
    Epoch 3 Batch 100 Loss 0.0705
    Epoch 3 Batch 200 Loss 0.0638
    Epoch 3 Batch 300 Loss 0.1077
    Epoch 3 Loss 0.0010
    Time taken for 1 epoch 106.98916363716125 sec
    
    Epoch 4 Batch 0 Loss 0.0479
    Epoch 4 Batch 100 Loss 0.0693
    Epoch 4 Batch 200 Loss 0.0545
    Epoch 4 Batch 300 Loss 0.0806
    Epoch 4 Loss 0.0009
    Time taken for 1 epoch 106.92719006538391 sec
    
    Epoch 5 Batch 0 Loss 0.0639
    Epoch 5 Batch 100 Loss 0.0671
    Epoch 5 Batch 200 Loss 0.0932
    Epoch 5 Batch 300 Loss 0.1052
    Epoch 5 Loss 0.0009
    Time taken for 1 epoch 106.91724753379822 sec
    
    Epoch 6 Batch 0 Loss 0.0995
    Epoch 6 Batch 100 Loss 0.0601
    Epoch 6 Batch 200 Loss 0.0787
    Epoch 6 Batch 300 Loss 0.0717
    Epoch 6 Loss 0.0009
    Time taken for 1 epoch 107.02709794044495 sec
    
    Epoch 7 Batch 0 Loss 0.0503
    Epoch 7 Batch 100 Loss 0.0649
    Epoch 7 Batch 200 Loss 0.0558
    Epoch 7 Batch 300 Loss 0.0538
    Epoch 7 Loss 0.0008
    Time taken for 1 epoch 107.0031886100769 sec
    
    Epoch 8 Batch 0 Loss 0.0615
    Epoch 8 Batch 100 Loss 0.0540
    Epoch 8 Batch 200 Loss 0.0538
    Epoch 8 Batch 300 Loss 0.0499
    Epoch 8 Loss 0.0007
    Time taken for 1 epoch 106.95856356620789 sec
    
    Epoch 9 Batch 0 Loss 0.0576
    Epoch 9 Batch 100 Loss 0.0358
    Epoch 9 Batch 200 Loss 0.0563
    Epoch 9 Batch 300 Loss 0.0893
    Epoch 9 Loss 0.0007
    Time taken for 1 epoch 106.9578447341919 sec
    
    Epoch 10 Batch 0 Loss 0.0227
    Epoch 10 Batch 100 Loss 0.0452
    Epoch 10 Batch 200 Loss 0.0880
    Epoch 10 Batch 300 Loss 0.0887
    Epoch 10 Loss 0.0008
    Time taken for 1 epoch 106.95288586616516 sec
    



```python
variables
```




    [<tf.Variable 'encoder/embedding/embeddings:0' shape=(9414, 256) dtype=float32, numpy=
     array([[ 0.5125716 ,  0.8245362 ,  0.56031436, ...,  0.08857868,
              0.50070614,  0.37458286],
            [ 1.2462964 ,  0.06821021,  0.47963914, ...,  0.8599553 ,
              0.2994965 ,  0.46479762],
            [ 0.3322044 ,  0.5755392 ,  0.7939083 , ...,  0.41400465,
              0.06411676,  0.12261444],
            ...,
            [ 0.80639356,  0.29617733,  0.8158936 , ...,  0.38865995,
              0.9668266 ,  0.56494653],
            [ 0.834935  ,  0.7107854 , -0.0145288 , ...,  0.60252774,
              0.3062037 ,  0.89033717],
            [ 0.66786337,  0.50030553, -0.15521693, ...,  0.7665484 ,
              0.38173717, -0.06104789]], dtype=float32)>,
     <tf.Variable 'encoder/cu_dnngru/kernel:0' shape=(256, 3072) dtype=float32, numpy=
     array([[ 0.05647275,  0.12643912,  0.0030217 , ..., -0.18959875,
             -0.00176977,  0.00756644],
            [ 0.04771179,  0.11252786,  0.01438036, ..., -0.00821857,
             -0.02848281, -0.02342363],
            [ 0.14585464,  0.19578905, -0.02143077, ...,  0.01251397,
             -0.00022872,  0.01895941],
            ...,
            [ 0.08978708,  0.07412432,  0.16555662, ...,  0.06957965,
             -0.03999444,  0.03942523],
            [ 0.10004193, -0.05256743, -0.07195537, ...,  0.02344164,
             -0.17704818, -0.03172789],
            [ 0.15640189,  0.11383372,  0.18661596, ...,  0.07759208,
              0.22009766, -0.05422935]], dtype=float32)>,
     <tf.Variable 'encoder/cu_dnngru/recurrent_kernel:0' shape=(1024, 3072) dtype=float32, numpy=
     array([[-0.12056907,  0.08446644,  0.03650257, ...,  0.00838423,
              0.00068115, -0.01628181],
            [ 0.13048874, -0.0353396 , -0.08295404, ..., -0.09453208,
             -0.05619559, -0.06576883],
            [ 0.09997623, -0.14332835,  0.02930105, ...,  0.0511219 ,
             -0.20229807,  0.0625985 ],
            ...,
            [-0.10349798,  0.11087519,  0.0370854 , ..., -0.0259274 ,
              0.25072467, -0.06691515],
            [-0.00363301, -0.21508543, -0.10224565, ...,  0.1750885 ,
             -0.11487406, -0.01729714],
            [-0.01429075,  0.04541343, -0.05324581, ..., -0.0851867 ,
              0.08538142, -0.20402601]], dtype=float32)>,
     <tf.Variable 'encoder/cu_dnngru/bias:0' shape=(6144,) dtype=float32, numpy=
     array([ 0.10713962,  0.04758238,  0.09006279, ...,  0.0342539 ,
            -0.04041943,  0.05886756], dtype=float32)>,
     <tf.Variable 'decoder/embedding_1/embeddings:0' shape=(4935, 256) dtype=float32, numpy=
     array([[ 0.37727034,  0.97630787,  0.44436955, ...,  0.54193854,
              0.57043004,  0.6408737 ],
            [ 0.27441478,  0.89716023,  0.18861386, ..., -0.11717845,
              0.39793026,  0.79658914],
            [ 0.5958674 ,  0.13313253,  0.13275252, ...,  0.43342897,
             -0.24585119,  0.05612883],
            ...,
            [ 0.24937752,  0.40118635,  0.11943883, ...,  0.7417854 ,
              0.09413297,  0.92955756],
            [ 0.68694717,  0.37322205,  0.37913743, ...,  0.32249418,
              0.72410995,  0.2504804 ],
            [ 0.7538345 ,  0.82255584,  0.54318184, ...,  0.9853122 ,
              0.7202844 ,  0.59532726]], dtype=float32)>,
     <tf.Variable 'decoder/cu_dnngru_1/kernel:0' shape=(1280, 3072) dtype=float32, numpy=
     array([[ 0.00217096, -0.05270639,  0.07017374, ...,  0.00049577,
             -0.04105439,  0.05357133],
            [ 0.17115839,  0.07053174,  0.08805104, ..., -0.01851003,
              0.18050246,  0.10671062],
            [ 0.0533663 , -0.10439972, -0.19603212, ..., -0.07664321,
             -0.02564928, -0.01723737],
            ...,
            [-0.02655713,  0.02716263,  0.0439059 , ..., -0.01578368,
              0.12837152, -0.05996147],
            [ 0.06520826, -0.03252339, -0.02701292, ..., -0.10969949,
             -0.01167891, -0.01659868],
            [-0.01158092,  0.07097146, -0.03726837, ...,  0.02795699,
             -0.07369915,  0.07644657]], dtype=float32)>,
     <tf.Variable 'decoder/cu_dnngru_1/recurrent_kernel:0' shape=(1024, 3072) dtype=float32, numpy=
     array([[ 0.02747554,  0.02147451,  0.01014565, ..., -0.02249051,
              0.00277331, -0.03604835],
            [-0.02498855, -0.01755066, -0.01512419, ..., -0.02890566,
             -0.02304563,  0.00156589],
            [-0.0084874 , -0.02431068, -0.01287225, ...,  0.02360742,
             -0.00960023, -0.0320627 ],
            ...,
            [ 0.03421916,  0.00392421,  0.02169918, ..., -0.00328189,
             -0.02543863,  0.01539508],
            [ 0.021786  ,  0.01643413,  0.03023139, ..., -0.01914966,
              0.01078497, -0.030706  ],
            [ 0.02772627, -0.0136281 , -0.02703421, ..., -0.00530173,
             -0.018201  , -0.00594125]], dtype=float32)>,
     <tf.Variable 'decoder/cu_dnngru_1/bias:0' shape=(6144,) dtype=float32, numpy=
     array([ 0.05055702, -0.02088807,  0.02115502, ...,  0.3770219 ,
             0.21442558,  0.17604713], dtype=float32)>,
     <tf.Variable 'decoder/dense/kernel:0' shape=(1024, 4935) dtype=float32, numpy=
     array([[ 0.00878861, -0.00934059, -0.11906984, ...,  0.06399   ,
             -0.01260871,  0.01584625],
            [-0.10891102,  0.00981549, -0.20559359, ..., -0.16126108,
              0.00574301, -0.12724957],
            [ 0.02222733,  0.01945349, -0.14418148, ...,  0.27139786,
              0.03817095,  0.43200555],
            ...,
            [-0.0159625 ,  0.03815438,  0.26305383, ..., -0.03523752,
             -0.04828529, -0.03326441],
            [-0.2151772 , -0.01781422, -0.02184848, ..., -0.0386366 ,
             -0.1295891 , -0.01707274],
            [-0.03009269,  0.10681094,  0.03353693, ..., -0.04897442,
             -0.06060501,  0.02388209]], dtype=float32)>,
     <tf.Variable 'decoder/dense/bias:0' shape=(4935,) dtype=float32, numpy=
     array([-0.13658687, -0.05867943,  0.02581985, ..., -0.01222606,
            -0.01300115, -0.01975876], dtype=float32)>,
     <tf.Variable 'decoder/dense_1/kernel:0' shape=(1024, 1024) dtype=float32, numpy=
     array([[ 6.93090260e-02,  8.89268238e-03, -1.51147164e-04, ...,
              8.18594545e-02,  5.38322292e-02,  1.99863344e-01],
            [ 5.12450002e-02, -3.50729600e-02,  1.37878731e-01, ...,
             -5.64428084e-02, -2.09993664e-02, -9.25710425e-02],
            [-1.17301457e-01,  3.65767218e-02, -3.77184292e-03, ...,
             -9.06740054e-02, -3.35868634e-02,  1.01287728e-02],
            ...,
            [ 7.09840208e-02,  7.85668194e-02, -1.21936753e-01, ...,
             -5.09303398e-02,  1.17165528e-01,  9.10963640e-02],
            [ 4.73005548e-02,  1.38528123e-01,  1.03264116e-01, ...,
             -2.30807811e-02, -2.91146487e-02, -3.95517610e-02],
            [-1.67916924e-01,  8.10872857e-03, -1.08221605e-01, ...,
             -5.44666760e-02, -2.09022790e-01, -8.62360448e-02]], dtype=float32)>,
     <tf.Variable 'decoder/dense_1/bias:0' shape=(1024,) dtype=float32, numpy=
     array([-0.20730965,  0.1156992 ,  0.09012564, ...,  0.15175709,
            -0.21258949, -0.09784171], dtype=float32)>,
     <tf.Variable 'decoder/dense_2/kernel:0' shape=(1024, 1024) dtype=float32, numpy=
     array([[ 0.07776069, -0.07518496,  0.00612192, ..., -0.07581972,
              0.11973829,  0.05187117],
            [ 0.06753718,  0.02327386,  0.01481008, ...,  0.0965778 ,
              0.0087077 ,  0.04642152],
            [ 0.0469464 , -0.10683208, -0.03699944, ..., -0.09603196,
              0.04828569,  0.10483956],
            ...,
            [ 0.10002374,  0.01240953,  0.02107581, ..., -0.00363053,
              0.0844178 , -0.00760011],
            [-0.11891323, -0.0957351 , -0.05983981, ...,  0.08439154,
             -0.05756417,  0.28186187],
            [-0.01786883,  0.10946683,  0.00634295, ...,  0.0443297 ,
             -0.16089886, -0.18263306]], dtype=float32)>,
     <tf.Variable 'decoder/dense_2/bias:0' shape=(1024,) dtype=float32, numpy=
     array([-0.20730965,  0.11569924,  0.09012564, ...,  0.15175714,
            -0.21258955, -0.09784171], dtype=float32)>,
     <tf.Variable 'decoder/dense_3/kernel:0' shape=(1024, 1) dtype=float32, numpy=
     array([[ 0.1275346 ],
            [ 0.05505249],
            [ 0.03621905],
            ...,
            [ 0.10067593],
            [ 0.03566581],
            [-0.05378475]], dtype=float32)>,
     <tf.Variable 'decoder/dense_3/bias:0' shape=(1,) dtype=float32, numpy=array([0.06740692], dtype=float32)>]




```python
gradients
```




    [<tensorflow.python.framework.ops.IndexedSlices at 0x7f836afe9c18>,
     <tf.Tensor: id=34183942, shape=(256, 3072), dtype=float32, numpy=
     array([[ 1.3320980e-05,  1.1937304e-06,  1.5188846e-05, ...,
             -6.1289077e-03, -6.8325251e-03, -6.7553045e-03],
            [ 7.6430792e-04,  9.2332793e-04,  9.5788017e-04, ...,
             -6.4348206e-03, -6.4439685e-03, -2.2767247e-03],
            [-1.7040879e-04,  2.3813382e-05,  4.1113031e-05, ...,
              2.6975805e-08,  1.2291669e-07, -7.2973826e-08],
            ...,
            [ 5.1773856e-07,  3.6202889e-06,  1.3878347e-06, ...,
             -1.8668642e-03, -3.9470736e-03, -4.9874648e-03],
            [-1.7135552e-04, -1.5373500e-04, -7.4765339e-05, ...,
             -4.9537161e-06,  1.7965385e-06, -4.7396575e-06],
            [-3.3016795e-07, -1.9032890e-07, -3.7650699e-07, ...,
              6.1659439e-04,  8.4192702e-04,  7.3360937e-04]], dtype=float32)>,
     <tf.Tensor: id=34183943, shape=(1024, 3072), dtype=float32, numpy=
     array([[ 9.55782227e-08, -1.21290566e-06, -3.57108178e-07, ...,
             -9.53014750e-11, -2.91123192e-09, -1.06721787e-09],
            [ 4.70716742e-07,  6.50925504e-05, -1.17676376e-04, ...,
             -3.11874169e-06,  1.38373711e-04, -1.46005887e-05],
            [-3.18268548e-07,  1.73821518e-05,  3.66511376e-05, ...,
              5.48530430e-08, -9.56562616e-08,  1.87979712e-08],
            ...,
            [-1.47772198e-07, -4.93077132e-05,  2.43183217e-06, ...,
              3.95401997e-07,  1.43501502e-05,  5.10883126e-07],
            [-7.45207842e-08,  2.04109574e-06,  1.11984868e-07, ...,
             -7.21051174e-06,  2.55349907e-04, -3.24771718e-05],
            [-2.52178324e-07, -1.84596338e-05,  3.14868380e-08, ...,
             -4.34212780e-06,  5.49450451e-05, -6.99889351e-05]], dtype=float32)>,
     <tf.Tensor: id=34183944, shape=(6144,), dtype=float32, numpy=
     array([ 2.0691872e-05, -7.4579497e-04,  5.2995537e-04, ...,
            -3.2799150e-04, -3.4991250e-04, -1.8181725e-04], dtype=float32)>,
     <tensorflow.python.framework.ops.IndexedSlices at 0x7f836afe5c18>,
     <tf.Tensor: id=34183959, shape=(1280, 3072), dtype=float32, numpy=
     array([[ 2.6934222e-08,  2.7850299e-06, -3.8094313e-07, ...,
             -9.7502664e-09, -1.7752842e-05,  1.7620296e-06],
            [ 1.4840245e-05,  1.8185539e-05,  8.7225835e-06, ...,
             -1.5923055e-05, -1.1834924e-05,  3.1072382e-04],
            [-5.4678560e-05,  6.9472317e-10,  4.7670757e-05, ...,
             -1.1571997e-07, -6.6585741e-08,  4.7964124e-07],
            ...,
            [ 8.5634812e-05,  5.0200665e-08,  1.1441299e-04, ...,
              5.1580981e-04,  4.0272616e-06, -2.3554750e-04],
            [-3.8606759e-05,  1.9184035e-06,  2.1327313e-09, ...,
             -3.0748437e-05,  3.9031445e-05,  1.7897704e-05],
            [ 7.6263937e-06,  5.4614109e-05, -3.0694104e-05, ...,
             -6.9854301e-05, -8.2122126e-05, -1.1458280e-04]], dtype=float32)>,
     <tf.Tensor: id=34183960, shape=(1024, 3072), dtype=float32, numpy=
     array([[0., 0., 0., ..., 0., 0., 0.],
            [0., 0., 0., ..., 0., 0., 0.],
            [0., 0., 0., ..., 0., 0., 0.],
            ...,
            [0., 0., 0., ..., 0., 0., 0.],
            [0., 0., 0., ..., 0., 0., 0.],
            [0., 0., 0., ..., 0., 0., 0.]], dtype=float32)>,
     <tf.Tensor: id=34183961, shape=(6144,), dtype=float32, numpy=
     array([ 1.7177916e-05, -2.4467340e-04, -7.9221773e-04, ...,
             2.1033592e-03,  4.1573821e-05, -7.2301584e-05], dtype=float32)>,
     <tf.Tensor: id=34183962, shape=(1024, 4935), dtype=float32, numpy=
     array([[ 9.60431387e-13, -1.64402536e-06,  1.25297356e-06, ...,
              3.88627186e-11, -1.13780175e-11,  8.16182469e-11],
            [-6.27630670e-10, -3.30917793e-03, -3.79184098e-03, ...,
              1.65669540e-08, -1.49576636e-08,  1.72503452e-08],
            [-1.22478097e-10, -1.08471478e-03, -1.89061696e-03, ...,
             -1.02110782e-08, -5.03717645e-09, -3.57354004e-08],
            ...,
            [-3.32506078e-10, -1.48436299e-03, -1.55910835e-04, ...,
             -7.98309117e-08,  1.12833280e-08,  4.70193449e-08],
            [-1.25405131e-10, -1.14319543e-03, -8.53614707e-04, ...,
              1.20053061e-08,  2.42034730e-08,  7.92149820e-07],
            [ 2.39398171e-11,  3.32313735e-04,  3.13406531e-03, ...,
              1.29880915e-08,  2.33050201e-09,  3.52683600e-07]], dtype=float32)>,
     <tf.Tensor: id=34183963, shape=(4935,), dtype=float32, numpy=
     array([1.4895143e-09, 6.6241651e-04, 3.8278322e-03, ..., 1.5278970e-07,
            5.4288037e-08, 8.2394934e-07], dtype=float32)>,
     <tf.Tensor: id=34183964, shape=(1024, 1024), dtype=float32, numpy=
     array([[-1.5764344e-08, -8.9750598e-09,  8.1490231e-07, ...,
              2.6494674e-06, -4.2059298e-08,  4.4491966e-08],
            [ 3.1928508e-07,  9.9849467e-07, -1.6517184e-05, ...,
             -9.2289898e-05,  9.5589961e-08,  1.1362961e-07],
            [ 2.0002739e-07,  4.4941011e-09, -2.7361591e-07, ...,
             -6.2344130e-05,  1.2964976e-07,  3.6326064e-08],
            ...,
            [ 6.8510963e-07,  6.0286089e-07, -3.9962106e-06, ...,
             -2.4562893e-05,  5.5130687e-07, -4.5529382e-07],
            [-1.8374883e-06,  2.5934937e-06, -1.9768273e-04, ...,
              4.2089421e-04, -5.1326697e-06,  3.0847980e-06],
            [ 6.2796630e-07,  7.3664496e-06,  6.0721436e-06, ...,
             -1.6097102e-04,  5.5084374e-06, -5.9462013e-06]], dtype=float32)>,
     <tf.Tensor: id=34183965, shape=(1024,), dtype=float32, numpy=
     array([-1.8165090e-05,  3.6203858e-06,  1.9030007e-04, ...,
            -8.8089530e-04,  8.7988825e-05, -2.3521391e-06], dtype=float32)>,
     <tf.Tensor: id=34183966, shape=(1024, 1024), dtype=float32, numpy=
     array([[-1.28056399e-07,  6.14251334e-08,  7.40652467e-07, ...,
              1.12141115e-05,  1.12992630e-07,  1.39186497e-07],
            [-1.99488659e-05,  2.17846773e-05,  3.30998250e-06, ...,
              3.16986261e-04, -3.49247930e-05,  3.43144238e-05],
            [-1.16945967e-06,  5.82534092e-08, -6.68772118e-05, ...,
              5.09851016e-05, -1.82216624e-07,  1.45464010e-05],
            ...,
            [ 1.86581001e-05, -8.63245714e-06,  8.84969995e-05, ...,
             -7.75204971e-04,  6.24467430e-05, -1.97323629e-06],
            [ 4.13186763e-06,  1.36263679e-07,  2.50218465e-04, ...,
              3.68414214e-04, -5.36301959e-05,  9.09687806e-05],
            [-1.28744404e-07, -1.27473345e-06,  2.78979889e-04, ...,
             -1.39442127e-04, -5.38412223e-06,  9.67049782e-05]], dtype=float32)>,
     <tf.Tensor: id=34183967, shape=(1024,), dtype=float32, numpy=
     array([-1.8165087e-05,  3.6203842e-06,  1.9030002e-04, ...,
            -8.8089536e-04,  8.7988832e-05, -2.3521684e-06], dtype=float32)>,
     <tf.Tensor: id=34183968, shape=(1024, 1), dtype=float32, numpy=
     array([[-0.00116514],
            [-0.0001429 ],
            [-0.02921851],
            ...,
            [ 0.03778503],
            [ 0.00269587],
            [ 0.00176942]], dtype=float32)>,
     <tf.Tensor: id=34183969, shape=(1,), dtype=float32, numpy=array([-4.603298e-08], dtype=float32)>]



## Translate

* The evaluate function is similar to the training loop, except we don't use *teacher forcing* here. The input to the decoder at each time step is its previous predictions along with the hidden state and the encoder output.
* Stop predicting when the model predicts the *end token*.
* And store the *attention weights for every time step*.

Note: The encoder output is calculated only once for one input.


```python
def evaluate(sentence, encoder, decoder, inp_lang, targ_lang, max_length_inp, max_length_targ):
    attention_plot = np.zeros((max_length_targ, max_length_inp))
    
    sentence = preprocess_sentence(sentence)

    inputs = [inp_lang.word2idx[i] for i in sentence.split(' ')]
    inputs = tf.keras.preprocessing.sequence.pad_sequences([inputs], maxlen=max_length_inp, padding='post')
    inputs = tf.convert_to_tensor(inputs)
    
    result = ''

    hidden = [tf.zeros((1, units))]
    enc_out, enc_hidden = encoder(inputs, hidden)

    dec_hidden = enc_hidden
    dec_input = tf.expand_dims([targ_lang.word2idx['<start>']], 0)

    for t in range(max_length_targ):
        predictions, dec_hidden, attention_weights = decoder(dec_input, dec_hidden, enc_out)
        
        # storing the attention weights to plot later on
        attention_weights = tf.reshape(attention_weights, (-1, ))
        attention_plot[t] = attention_weights.numpy()

        predicted_id = tf.multinomial(tf.exp(predictions), num_samples=1)[0][0].numpy()

        result += targ_lang.idx2word[predicted_id] + ' '

        if targ_lang.idx2word[predicted_id] == '<end>':
            return result, sentence, attention_plot
        
        # the predicted ID is fed back into the model
        # teacher forcing 
        dec_input = tf.expand_dims([predicted_id], 0)

    return result, sentence, attention_plot
```


```python
# function for plotting the attention weights
def plot_attention(attention, sentence, predicted_sentence):
    fig = plt.figure(figsize=(10,10))
    ax = fig.add_subplot(1, 1, 1)
    ax.matshow(attention, cmap='viridis')
    
    fontdict = {'fontsize': 14}
    
    ax.set_xticklabels([''] + sentence, fontdict=fontdict, rotation=90)
    ax.set_yticklabels([''] + predicted_sentence, fontdict=fontdict)

    plt.show()
```


```python
def translate(sentence, encoder, decoder, inp_lang, targ_lang, max_length_inp, max_length_targ):
    result, sentence, attention_plot = evaluate(sentence, encoder, decoder, inp_lang, targ_lang, max_length_inp, max_length_targ)
    print(attention_plot.shape) # target(len(characters) in translated sentence x (len(characters) in to-be-translated sentence )
    print(attention_plot)    
    print('Input: {}'.format(sentence))
    print('Predicted translation: {}'.format(result))
    
    attention_plot = attention_plot[:len(result.split(' ')), :len(sentence.split(' '))]
    plot_attention(attention_plot, sentence.split(' '), result.split(' '))
```


```python
translate('hace mucho frio aqui.', encoder, decoder, inp_lang, targ_lang, max_length_inp, max_length_targ)
```

    (11, 16)
    [[5.58312284e-03 3.19238842e-01 2.92620540e-01 2.70406604e-01
      1.02667466e-01 5.34372125e-03 1.49080064e-03 1.37707661e-03
      2.86965253e-04 1.55349495e-04 1.43802405e-04 1.40846707e-04
      1.38705669e-04 1.36901304e-04 1.35313312e-04 1.33918744e-04]
     [1.07463971e-02 2.40573168e-01 3.06724191e-01 3.52005959e-01
      8.41065720e-02 3.02681583e-03 9.76605574e-04 5.85337461e-04
      2.24998861e-04 1.54785434e-04 1.48407868e-04 1.46651510e-04
      1.45770537e-04 1.45191923e-04 1.44767386e-04 1.44441234e-04]
     [2.17098580e-03 2.86218096e-02 4.33663130e-01 4.18928087e-01
      9.02863592e-02 8.73693265e-03 5.22647053e-03 3.16930842e-03
      1.26969314e-03 1.16498873e-03 1.14088855e-03 1.13118498e-03
      1.12607609e-03 1.12307630e-03 1.12115545e-03 1.11985230e-03]
     [2.37916072e-04 9.98051473e-05 6.32945299e-02 6.20618761e-01
      2.70931542e-01 2.05887929e-02 8.55059363e-03 3.95074859e-03
      1.92358473e-03 1.48238509e-03 1.41531811e-03 1.39263179e-03
      1.38351100e-03 1.37886661e-03 1.37626671e-03 1.37470954e-03]
     [2.26208545e-06 5.58863007e-07 6.26743073e-04 1.82887316e-02
      3.94641012e-01 2.63744175e-01 2.14396104e-01 3.12564969e-02
      1.24310032e-02 9.35671292e-03 9.15068947e-03 9.13252309e-03
      9.17459559e-03 9.22212470e-03 9.26759467e-03 9.30874143e-03]
     [3.38855244e-07 1.06856151e-08 2.65140290e-04 1.18311355e-02
      4.79809381e-02 8.77630711e-02 8.59021395e-02 1.47448093e-01
      1.00462079e-01 7.65247419e-02 7.44542778e-02 7.37956017e-02
      7.35521317e-02 7.34146908e-02 7.33297691e-02 7.32758045e-02]
     [1.84277610e-07 4.20396233e-08 1.22640515e-04 3.23587470e-03
      4.94329678e-03 1.28619270e-02 1.98154710e-02 3.81563939e-02
      9.68738496e-02 1.13877460e-01 1.16430931e-01 1.17477804e-01
      1.18248045e-01 1.18851885e-01 1.19345225e-01 1.19758956e-01]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]]
    Input: <start> hace mucho frio aqui . <end>
    Predicted translation: it s very cold here . <end> 



![png](output_33_1.png)



```python
translate('esta es mi vida.', encoder, decoder, inp_lang, targ_lang, max_length_inp, max_length_targ)
```

    (11, 16)
    [[1.55152977e-02 3.25485170e-01 3.93794268e-01 2.28037611e-01
      2.76244227e-02 4.58976533e-03 2.26523704e-03 6.35365606e-04
      2.76068022e-04 2.48043216e-04 2.49518111e-04 2.52341793e-04
      2.54621584e-04 2.56297877e-04 2.57521315e-04 2.58429762e-04]
     [5.74087538e-03 1.41449273e-01 6.88098073e-01 1.22589380e-01
      3.93056870e-02 1.13384752e-03 5.52284939e-04 2.35922053e-04
      1.18818767e-04 1.12821748e-04 1.11756875e-04 1.11095062e-04
      1.10566798e-04 1.10146451e-04 1.09816589e-04 1.09558205e-04]
     [7.34882057e-03 1.74410604e-02 7.94481412e-02 6.26035452e-01
      2.28567585e-01 1.45413009e-02 7.87315238e-03 4.03741514e-03
      1.85718434e-03 1.82291982e-03 1.83321896e-03 1.83899736e-03
      1.84058805e-03 1.83989294e-03 1.83818559e-03 1.83615158e-03]
     [1.30719959e-03 2.42735623e-04 2.87665962e-03 7.22534135e-02
      5.26438177e-01 1.66301116e-01 8.13084319e-02 2.09003296e-02
      1.63507834e-02 1.59925260e-02 1.59943644e-02 1.60063114e-02
      1.60097312e-02 1.60083883e-02 1.60059296e-02 1.60039160e-02]
     [3.41494015e-05 3.25196925e-06 1.01793121e-04 3.15275131e-04
      1.21040512e-02 1.84893787e-01 3.06514114e-01 8.22949037e-02
      5.36685735e-02 5.02703935e-02 5.05338721e-02 5.10555804e-02
      5.15254401e-02 5.19186482e-02 5.22456504e-02 5.25205061e-02]
     [3.81891482e-07 9.76641772e-08 3.80724941e-07 3.92862676e-05
      3.49493558e-03 8.62706639e-03 2.63602864e-02 5.20199426e-02
      1.09244905e-01 1.10556424e-01 1.12533078e-01 1.13938488e-01
      1.14922456e-01 1.15620866e-01 1.16129622e-01 1.16511784e-01]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]]
    Input: <start> esta es mi vida . <end>
    Predicted translation: this is my life . <end> 



![png](output_34_1.png)



```python
translate('¿todavia estan en casa?', encoder, decoder, inp_lang, targ_lang, max_length_inp, max_length_targ)
## here estan: are; todavia: still, the order is reversed, so the attention is not necessary on diagonal spots
```

    (11, 16)
    [[1.29955038e-01 8.00096616e-03 2.73544073e-01 5.73437214e-01
      5.03838994e-03 8.82216357e-03 4.72213491e-04 2.27544937e-04
      1.41602170e-04 5.85670241e-05 4.99334819e-05 4.94458654e-05
      4.99975285e-05 5.05539865e-05 5.09779493e-05 5.13059458e-05]
     [2.97635281e-03 6.29973970e-03 5.06366909e-01 4.24828768e-01
      2.02696491e-02 3.35562006e-02 2.80654244e-03 8.51094956e-04
      5.00623370e-04 2.60214932e-04 2.25054711e-04 2.15609776e-04
      2.12371524e-04 2.11131206e-04 2.10246435e-04 2.09492762e-04]
     [1.90966239e-03 5.55243576e-04 4.01730329e-01 1.54984996e-01
      1.62028074e-01 1.92806363e-01 4.84111086e-02 1.38632907e-02
      5.55768097e-03 3.12507944e-03 2.56107445e-03 2.51872139e-03
      2.49857712e-03 2.48910813e-03 2.48275069e-03 2.47794553e-03]
     [4.77667869e-04 8.67512790e-05 1.69202294e-02 2.28434633e-02
      3.15720886e-01 3.85828674e-01 1.54080778e-01 3.63365151e-02
      1.59950275e-02 1.02583021e-02 7.53551489e-03 7.00671179e-03
      6.82729436e-03 6.74442528e-03 6.68939110e-03 6.64843246e-03]
     [4.74098078e-06 1.05938840e-08 1.73964577e-06 6.32762894e-05
      2.03214698e-02 2.30030328e-01 3.11770231e-01 1.54706731e-01
      4.72468510e-02 4.01132666e-02 3.36141065e-02 3.26510370e-02
      3.24338973e-02 3.23644727e-02 3.23399082e-02 3.23379375e-02]
     [9.49887817e-06 1.17518786e-08 2.58929390e-06 6.91622772e-05
      2.99980189e-03 2.80768611e-02 1.37510151e-01 2.23842859e-01
      1.12150460e-01 8.62208754e-02 7.24263340e-02 6.84501156e-02
      6.74792230e-02 6.71169907e-02 6.68985918e-02 6.67465404e-02]
     [6.36365343e-08 5.76706016e-10 2.83983130e-08 4.46034846e-07
      1.08205386e-04 1.49522221e-03 6.76309457e-03 1.23286536e-02
      3.16355713e-02 9.05275717e-02 1.35056823e-01 1.41303569e-01
      1.43426999e-01 1.44693136e-01 1.45801395e-01 1.46859229e-01]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]]
    Input: <start> ¿ todavia estan en casa ? <end>
    Predicted translation: are you still at home ? <end> 



![png](output_35_1.png)



```python
# wrong translation
translate('trata de averiguarlo.', encoder, decoder, inp_lang, targ_lang, max_length_inp, max_length_targ)
```

    (11, 16)
    [[4.17562015e-03 8.69649768e-01 5.95332086e-02 6.20932430e-02
      3.45488242e-03 5.36125503e-04 1.22413097e-04 6.03801309e-05
      4.89952981e-05 4.73816108e-05 4.68658727e-05 4.65939411e-05
      4.63931683e-05 4.62143253e-05 4.60432857e-05 4.58766845e-05]
     [1.27266198e-02 1.74117491e-01 1.79170638e-01 6.13668561e-01
      1.74571481e-02 9.52842587e-04 4.17192059e-04 1.79730152e-04
      1.65708188e-04 1.63735793e-04 1.63396660e-04 1.63385921e-04
      1.63420365e-04 1.63427685e-04 1.63393706e-04 1.63321107e-04]
     [1.44714187e-03 2.03767195e-02 6.57028183e-02 4.44737136e-01
      3.18414241e-01 6.32391348e-02 1.34863770e-02 8.11793562e-03
      8.05626344e-03 8.05269182e-03 8.05536192e-03 8.05858802e-03
      8.06134474e-03 8.06345418e-03 8.06494243e-03 8.06590077e-03]
     [2.55209015e-04 3.11602629e-03 3.73076112e-03 1.52846962e-01
      4.86671925e-01 1.81087673e-01 3.56448479e-02 1.62348468e-02
      1.52233569e-02 1.51226874e-02 1.50902728e-02 1.50605878e-02
      1.50285130e-02 1.49950739e-02 1.49617381e-02 1.49295395e-02]
     [8.27022723e-06 6.35985925e-05 1.27018211e-04 6.18100865e-03
      9.71461907e-02 6.55775890e-02 1.14534430e-01 8.70220438e-02
      7.99425393e-02 7.90760070e-02 7.88050219e-02 7.86272213e-02
      7.84653202e-02 7.83038959e-02 7.81412572e-02 7.79785961e-02]
     [2.51072433e-05 5.96739003e-04 6.94588583e-04 7.09168892e-03
      7.01396763e-02 6.52383789e-02 9.29133892e-02 8.62540826e-02
      8.42641816e-02 8.41265172e-02 8.43210742e-02 8.45526457e-02
      8.47529992e-02 8.49086270e-02 8.50216076e-02 8.50986987e-02]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
     [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00
      0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]]
    Input: <start> trata de averiguarlo . <end>
    Predicted translation: try to find out . <end> 



![png](output_36_1.png)

